"""Where to live: metro scoring, rent-vs-buy, listing links."""
from __future__ import annotations

from urllib.parse import quote

import numpy as np
import pandas as pd

from . import budget as B
from . import careers as C
from . import data as D

FIELD_KEYWORDS = {
    "Computer & information sciences": ["ai", "tech", "software", "cloud", "semiconductor", "robotics", "autonomy", "data"],
    "Engineering": ["semiconductor", "aerospace", "robotics", "energy", "manufacturing", "hardware", "devices", "ev"],
    "Mathematics & statistics": ["quant", "finance", "trading", "insurance", "tech", "data", "fintech"],
    "Physical sciences": ["semiconductor", "energy", "aerospace", "national", "research", "space", "climate"],
    "Biological & biomedical sciences": ["biotech", "pharma", "genomics", "gene", "medical", "health", "life sciences"],
    "Health sciences": ["health", "medical", "public health", "clinical", "cdc"],
    "Psychology": ["health", "higher ed", "research", "medical"],
    "Social sciences (incl. economics)": ["policy", "government", "finance", "consulting", "federal", "economic"],
    "Business & finance": ["finance", "fintech", "asset", "trading", "consulting", "hq", "venture"],
    "Geosciences & climate": ["climate", "energy", "space"],
    "Agricultural & natural resources": ["ag", "food"],
    "Multidisciplinary sciences": ["research", "biotech", "ai", "health"],
    "Education": ["higher ed", "government"],
    "Humanities": ["higher ed", "media", "policy"],
    "Visual & performing arts": ["media", "music", "arts"],
}


def hub_match(field: str, hubs: str) -> int:
    h = hubs.lower()
    return sum(1 for k in FIELD_KEYWORDS.get(field, []) if k in h)


def monthly_mortgage(price: float, down_pct: float, rate: float, years: int = 30, tax_ins_pct: float = 1.5) -> float:
    loan = price * (1 - down_pct / 100)
    r = rate / 12
    pi = loan * r / (1 - (1 + r) ** (-12 * years)) if r > 0 else loan / (12 * years)
    return pi + price * tax_ins_pct / 100 / 12


def score_metros(p: dict, sector: str, weights: dict) -> pd.DataFrame:
    m = D.metros().copy()
    rate = D.rules()["housing"]["mortgage_rate_30y"]
    rows = []
    for _, r in m.iterrows():
        wf, src = C.wage_factor(r.id, p["field"], sector)
        sal = C.expected_salary(p, sector) * wf
        at = B.salary_after_tax(sal, r.state)
        real = at / (r.rpp / 100)
        price = r.list_price if pd.notna(r.list_price) else np.nan
        mort = monthly_mortgage(price, 10, rate) if pd.notna(price) else np.nan
        burden = mort / (sal / 12) if pd.notna(mort) else np.nan
        rows.append({"id": r.id, "Metro": r["name"], "state": r.state, "lat": r.lat, "lon": r.lon, "Salary": sal,
                     "After tax": at, "Real after-tax": real, "RPP": r.rpp, "Median list price": price,
                     "Mortgage (10% down)": mort, "Housing burden": burden, "Hub match": hub_match(p["field"], r.hubs),
                     "Hubs": r.hubs, "Universities": r.universities, "wage_source": src, "List YoY %": r.list_yoy,
                     "State tax": B.state_income_tax(r.state, sal)})
    df = pd.DataFrame(rows)

    def z(s, invert=False):
        s = s.astype(float)
        s = s.fillna(s.median())
        v = (s - s.mean()) / (s.std() or 1)
        return -v if invert else v
    raw = (weights["income"] * z(df["Real after-tax"]) + weights["housing"] * z(df["Housing burden"], invert=True) +
           weights["career"] * z(df["Hub match"]) + weights["cost"] * z(df["RPP"], invert=True))
    df["Score"] = (100 * (raw - raw.min()) / ((raw.max() - raw.min()) or 1)).round(0)
    return df.sort_values("Score", ascending=False).reset_index(drop=True)


def rent_vs_buy(price, down_pct, rate, years, tax_ins_pct, maint_pct, appreciation, rent, rent_growth, invest_ret,
                closing_buy=3.0, selling=6.0) -> pd.DataFrame:
    """Net worth difference (buy minus rent) each year; renters invest the down payment & any monthly savings."""
    down = price * down_pct / 100
    loan = price - down
    r = rate / 12
    n = 360
    pmt = loan * r / (1 - (1 + r) ** -n) if r > 0 else loan / n
    bal = loan
    home = price
    renter = down + price * closing_buy / 100
    rows = []
    cur_rent = rent
    for y in range(1, years + 1):
        own_cost_y = 0.0
        for _ in range(12):
            interest = bal * r
            bal -= pmt - interest
            own_cost_y += pmt
        own_cost_y += home * (tax_ins_pct + maint_pct) / 100
        home *= 1 + appreciation / 100
        rent_y = cur_rent * 12
        renter = renter * (1 + invest_ret / 100) + (own_cost_y - rent_y)
        cur_rent *= 1 + rent_growth / 100
        owner_equity = home * (1 - selling / 100) - bal
        rows.append({"year": y, "Buy: home equity after sale": owner_equity, "Rent: invested savings": renter,
                     "Buy minus rent": owner_equity - renter, "Monthly owning cost": own_cost_y / 12, "Monthly rent": rent_y / 12})
    return pd.DataFrame(rows)


def listing_links(city: str, state: str, mode: str, max_price: float | None) -> list[tuple[str, str]]:
    c = city.split(",")[0].split("-")[0].strip()
    slug_dash = c.lower().replace(" ", "-")
    zc = quote(f"{c}, {state}")
    if mode == "buy":
        mp = int(max_price) if max_price else None
        return [
            ("Zillow", f"https://www.zillow.com/homes/for_sale/{zc}_rb/"),
            ("Realtor.com", f"https://www.realtor.com/realestateandhomes-search/{c.replace(' ', '-')}_{state}" + (f"/price-na-{mp}" if mp else "")),
            ("Redfin", f"https://www.redfin.com/search#query={quote(c + ', ' + state)}"),
            ("Trulia", f"https://www.trulia.com/{state}/{c.replace(' ', '_')}/"),
        ]
    return [
        ("Zillow Rentals", f"https://www.zillow.com/homes/for_rent/{zc}_rb/"),
        ("Apartments.com", f"https://www.apartments.com/{slug_dash}-{state.lower()}/" + (f"under-{int(max_price)}/" if max_price else "")),
        ("Zumper", f"https://www.zumper.com/apartments-for-rent/{slug_dash}-{state.lower()}"),
        ("Realtor.com Rentals", f"https://www.realtor.com/apartments/{c.replace(' ', '-')}_{state}"),
    ]


# --------------------------------------------------------------------------------------
# Neighborhood (ZIP-code) prices: works with no API key
# --------------------------------------------------------------------------------------
def _miles(lat1, lon1, lat2, lon2):
    p = np.pi / 180
    a = np.sin((lat2 - lat1) * p / 2) ** 2 + np.cos(lat1 * p) * np.cos(lat2 * p) * np.sin((lon2 - lon1) * p / 2) ** 2
    return 3958.8 * 2 * np.arcsin(np.sqrt(a))


def neighborhoods(lat: float, lon: float, mode: str, beds: int, max_price: float | None, radius: float = 12.0) -> pd.DataFrame:
    """ZIP codes within `radius` miles of the city center with a comparable price for the search:
    rent -> HUD FY2026 Small Area FMR for the bedroom count (Zillow typical rent if HUD is missing);
    buy  -> Realtor.com median list price (Zillow typical home value if missing)."""
    z = D.zip_housing().copy()
    z["miles"] = _miles(lat, lon, z.lat.values, z.lon.values)
    z = z[z.miles <= radius].copy()
    b = int(min(max(beds or 0, 0), 4))
    if mode == "buy":
        z["price"] = z.rdc_median_list.fillna(z.zhvi)
        z["price_src"] = np.where(z.rdc_median_list.notna(), "Realtor.com median list", "Zillow typical value")
    else:
        z["price"] = z[f"hud_{b}br"].fillna(z.zori)
        z["price_src"] = np.where(z[f"hud_{b}br"].notna(), f"HUD {b}-bed rent" if b else "HUD studio rent", "Zillow typical rent")
    z = z[z.price.notna()].copy()
    z["city"] = z.city.fillna("")
    z["in_budget"] = z.price <= max_price if max_price else True
    return z.sort_values("miles").reset_index(drop=True)


def zip_links(zip_code: str, mode: str) -> list[tuple[str, str]]:
    """Listing searches for one ZIP code on the big sites (the listings themselves live there)."""
    if mode == "buy":
        return [("Zillow", f"https://www.zillow.com/homes/for_sale/{zip_code}_rb/"),
                ("Realtor.com", f"https://www.realtor.com/realestateandhomes-search/{zip_code}"),
                ("Redfin", f"https://www.redfin.com/zipcode/{zip_code}")]
    return [("Zillow", f"https://www.zillow.com/homes/for_rent/{zip_code}_rb/"),
            ("Realtor.com", f"https://www.realtor.com/apartments/{zip_code}"),
            ("Redfin", f"https://www.redfin.com/zipcode/{zip_code}/apartments-for-rent")]
