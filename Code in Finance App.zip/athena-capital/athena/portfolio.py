"""Module 2: portfolio builder, historical simulator (1M ... 10Y), risk stats, factor exposure, Monte Carlo."""
from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np
import pandas as pd

from . import data as D

CORE = {("Large", "Blend"): "VOO", ("Large", "Growth"): "VUG", ("Large", "Value"): "VTV",
        ("Mid", "Blend"): "VO", ("Mid", "Growth"): "VOT", ("Mid", "Value"): "VOE",
        ("Small", "Blend"): "VB", ("Small", "Growth"): "VBK", ("Small", "Value"): "VBR",
        ("Total", "Blend"): "VTI", ("Total", "Growth"): "VUG", ("Total", "Value"): "VTV"}
SATELLITES = ["XLK", "XLV", "XLF", "XLE", "XLI", "XLY", "XLP", "XLU", "XLB", "XLRE", "XLC", "SOXX", "IBB", "ICLN", "QQQ", "SCHD"]
BOND_TYPES = {"BND": "US Aggregate", "SHY": "Short Treasuries", "TLT": "Long Treasuries", "TIP": "TIPS", "BNDX": "International (hedged)"}
HORIZONS = {"1M": 1, "3M": 3, "6M": 6, "YTD": None, "1Y": 12, "3Y": 36, "5Y": 60, "10Y": 120}
CLASS_OF = {"BND": "bond", "TLT": "bond", "TIP": "bond", "BNDX": "bond", "SHY": "cash", "BIL": "cash", "GLD": "gold"}

PRESETS = {
    "Recommended for my profile": None,  # filled from the profile
    "Three-fund classic": {"us": 60, "intl": 25, "em": 5, "bonds": 10, "reit": 0, "gold": 0, "cash": 0, "size": "Total", "style": "Blend", "bond_type": "BND", "sat": []},
    "Aggressive growth": {"us": 75, "intl": 10, "em": 10, "bonds": 5, "reit": 0, "gold": 0, "cash": 0, "size": "Large", "style": "Growth", "bond_type": "BND", "sat": [("QQQ", 10), ("SOXX", 5)]},
    "All-weather style": {"us": 30, "intl": 0, "em": 0, "bonds": 40, "reit": 0, "gold": 15, "cash": 15, "size": "Total", "style": "Blend", "bond_type": "TLT", "sat": []},
    "Income & dividends": {"us": 45, "intl": 10, "em": 0, "bonds": 30, "reit": 10, "gold": 0, "cash": 5, "size": "Large", "style": "Value", "bond_type": "BND", "sat": [("SCHD", 15)]},
}


def recommended_spec(equity: float, field_hedge: bool, esg: bool = False) -> dict:
    eq = round(equity * 100)
    bonds = 100 - eq
    spec = {"us": round(eq * 0.65), "intl": round(eq * 0.28), "em": eq - round(eq * 0.65) - round(eq * 0.28),
            "bonds": max(0, bonds - 5), "reit": 0, "gold": 0, "cash": min(5, bonds),
            "size": "Total", "style": "Value" if field_hedge else "Blend", "bond_type": "BND", "sat": [], "esg": esg}
    return spec


def build_weights(spec: dict) -> dict[str, float]:
    alloc = {k: max(0.0, float(spec.get(k, 0))) for k in ("us", "intl", "em", "bonds", "reit", "gold", "cash")}
    tot = sum(alloc.values()) or 1.0
    alloc = {k: v / tot for k, v in alloc.items()}
    w: dict[str, float] = {}

    def add(t, x):
        if x > 1e-6:
            w[t] = w.get(t, 0) + x
    sat_total = 0.0
    for t, pct in spec.get("sat", []):
        x = min(pct / 100, alloc["us"] - sat_total)
        if x > 0:
            add(t, x)
            sat_total += x
    core = "ESGU" if spec.get("esg") else CORE[(spec.get("size", "Total"), spec.get("style", "Blend"))]
    add(core, alloc["us"] - sat_total)
    add("VEA", alloc["intl"])
    add("VWO", alloc["em"])
    add(spec.get("bond_type", "BND"), alloc["bonds"])
    add("VNQ", alloc["reit"])
    add("GLD", alloc["gold"])
    add("BIL", alloc["cash"])
    return w


def class_mix(w: dict) -> dict:
    out = {"stock": 0.0, "bond": 0.0, "gold": 0.0, "cash": 0.0}
    for t, x in w.items():
        out[CLASS_OF.get(t, "stock")] += x
    return out


# --------------------------------------------------------------------------------------
# Price panel: ETF daily cache, else monthly long-run proxies
# --------------------------------------------------------------------------------------
@dataclass
class Panel:
    prices: pd.DataFrame     # price index per ticker
    freq: str                # "D" or "M"
    proxy: bool
    note: str


def panel_for(tickers: list[str]) -> Panel:
    etf = D.load_etf_prices()
    tickers = list(dict.fromkeys(tickers + ["SPY", "BIL", "VTI", "BND"]))
    if etf is not None and all(t in etf.columns for t in tickers if t in D.ETFS):
        px = etf[[t for t in tickers if t in etf.columns]].ffill()
        return Panel(px, "D", False, f"Yahoo Finance adjusted closes through {px.index[-1]:%b %d, %Y}")
    crsp = D.load_crsp_monthly()
    if crsp is not None and all(t in crsp.columns for t in tickers if t in D.ETFS):
        r = crsp[list(tickers)].dropna(how="all").fillna(0.0)
        px = (1 + r).cumprod()
        return Panel(px, "M", False, f"CRSP monthly total returns via WRDS through {px.index[-1]:%b %Y} "
                                     "(refresh Yahoo Finance prices for daily data and the latest months)")
    lr = D.longrun()
    idx = {c: (1 + lr[c]).cumprod() for c in ["stock", "bond", "gold", "cash"]}
    px = pd.DataFrame({t: idx[CLASS_OF.get(t, "stock")] for t in tickers})
    return Panel(px, "M", True, f"PROXY MODE: no ETF prices cached yet, so each ETF is mapped to its asset class "
                                f"(S&P 500, 10y Treasury, gold, cash) through {lr.index[-1]:%b %Y}. Click 'Update market data' for real ETF prices.")


def window_start(end: pd.Timestamp, horizon: str, first: pd.Timestamp) -> pd.Timestamp:
    if horizon == "YTD":
        s = pd.Timestamp(year=end.year, month=1, day=1)
    elif horizon == "Max":
        s = first
    else:
        s = end - pd.DateOffset(months=HORIZONS[horizon])
    return max(s, first)


def simulate(w: dict, panel: Panel, horizon: str, lump: float, monthly: float, rebalance: str = "Quarterly",
             fee_bps: float = 5) -> dict:
    px = panel.prices[list(w)].dropna()
    if px.empty:
        return {}
    end = px.index[-1]
    start = window_start(end, horizon, px.index[0])
    px = px.loc[px.index >= start]
    if len(px) < 2:
        return {}
    rets = px.pct_change().fillna(0.0).to_numpy()
    tick = list(w)
    tw = np.array([w[t] for t in tick])
    fee = fee_bps / 10000 / (252 if panel.freq == "D" else 12)
    hold = tw * lump
    contributed = lump
    vals, flows = [], []
    last_month = px.index[0].month
    last_q = (px.index[0].month - 1) // 3
    last_y = px.index[0].year
    for i, dt in enumerate(px.index):
        if i > 0:
            hold = hold * (1 + rets[i]) * (1 - fee)
        newm = dt.month != last_month
        add = 0.0
        if monthly and (newm or (panel.freq == "M" and i > 0)):
            hold = hold + tw * monthly
            contributed += monthly
            add = monthly
        if newm:
            last_month = dt.month
        q = (dt.month - 1) // 3
        reb = (rebalance == "Monthly" and newm) or (rebalance == "Quarterly" and q != last_q) or (rebalance == "Annually" and dt.year != last_y)
        if reb:
            hold = tw * hold.sum()
        last_q, last_y = q, dt.year
        vals.append(hold.sum())
        flows.append(add)
    val = pd.Series(vals, index=px.index)
    flow = pd.Series(flows, index=px.index)
    # time-weighted return: strip out contributions
    prev = val.shift(1)
    twr_r = ((val - flow) / prev - 1).fillna(0.0)
    twr = float((1 + twr_r).prod() - 1)
    years = max((px.index[-1] - px.index[0]).days / 365.25, 1e-9)
    per = 252 if panel.freq == "D" else 12
    vol = float(twr_r.std() * math.sqrt(per))
    growth = (1 + twr_r).cumprod()
    dd = float((growth / growth.cummax() - 1).min())
    rf = panel.prices["BIL"].loc[px.index].pct_change().fillna(0.0) if "BIL" in panel.prices else pd.Series(0.0, index=px.index)
    ex = twr_r - rf
    sharpe = float(ex.mean() / ex.std() * math.sqrt(per)) if ex.std() > 0 else float("nan")
    # per-holding contribution (buy & hold approximation)
    hold_ret = px.iloc[-1] / px.iloc[0] - 1
    contrib = {t: w[t] * float(hold_ret[t]) for t in tick}
    return {"value": val, "growth": growth, "twr": twr, "ann": (1 + twr) ** (1 / years) - 1 if years >= 1 else None,
            "vol": vol, "max_dd": dd, "sharpe": sharpe, "end_value": float(val.iloc[-1]), "contributed": contributed,
            "gain": float(val.iloc[-1] - contributed), "start": px.index[0], "end": px.index[-1], "contrib": contrib,
            "best": float(twr_r.max()), "worst": float(twr_r.min()), "rets": twr_r}


def trailing_table(tickers: list[str], panel: Panel) -> pd.DataFrame:
    px = panel.prices
    rows = []
    end = px.index[-1]
    for t in tickers:
        s = px[t].dropna()
        row = {"Ticker": t, "Fund": D.ETFS.get(t, {}).get("name", t)}
        for h in ["1M", "3M", "6M", "YTD", "1Y", "3Y", "5Y"]:
            st = window_start(end, h, s.index[0])
            sub = s.loc[s.index >= st]
            if len(sub) < 2 or (h not in ("YTD",) and HORIZONS[h] and (end - s.index[0]).days < HORIZONS[h] * 28):
                row[h] = np.nan
                continue
            r = sub.iloc[-1] / sub.iloc[0] - 1
            if h in ("3Y", "5Y"):
                r = (1 + r) ** (1 / (HORIZONS[h] / 12)) - 1  # annualized
            row[h] = r
        rows.append(row)
    return pd.DataFrame(rows)


def correlation(w: dict, panel: Panel, horizon: str = "3Y") -> pd.DataFrame:
    px = panel.prices[list(w)].dropna()
    st = window_start(px.index[-1], horizon, px.index[0])
    return px.loc[px.index >= st].pct_change().dropna().corr()


def factor_exposure(sim: dict, panel: Panel) -> dict | None:
    """Fama-French regression (WRDS factors) on monthly returns; else CAPM beta vs SPY."""
    r = sim["rets"]
    m = (1 + r).resample("ME").prod() - 1 if panel.freq == "D" else r
    m.index = m.index.to_period("M").to_timestamp()
    ff = D.load_ff_factors()
    if ff is not None:
        j = pd.concat([m.rename("p"), ff], axis=1, join="inner").dropna()
        if len(j) >= 24:
            cols = [c for c in ["mktrf", "smb", "hml", "umd"] if c in j]
            X = np.column_stack([np.ones(len(j))] + [j[c] for c in cols])
            y = j["p"] - j["rf"]
            b, *_ = np.linalg.lstsq(X, y, rcond=None)
            resid = y - X @ b
            r2 = 1 - resid.var() / y.var()
            return {"model": "Fama-French (WRDS)", "alpha_ann": b[0] * 12, "betas": dict(zip(cols, b[1:], strict=True)), "r2": r2, "n": len(j)}
    if "SPY" in panel.prices:
        spy = panel.prices["SPY"].loc[sim["start"]:sim["end"]].pct_change().dropna()
        j = pd.concat([r.rename("p"), spy.rename("m")], axis=1, join="inner").dropna()
        if len(j) > 20 and j["m"].var() > 0:
            beta = j.cov().iloc[0, 1] / j["m"].var()
            return {"model": "CAPM vs S&P 500", "alpha_ann": None, "betas": {"market": beta}, "r2": j.corr().iloc[0, 1] ** 2, "n": len(j)}
    return None


def vol_multiplier(w: dict, panel: Panel) -> float:
    """How volatile the equity sleeve is vs the S&P 500 (scales Monte Carlo equity shocks)."""
    if panel.proxy:
        return 1.0
    eq = {t: x for t, x in w.items() if CLASS_OF.get(t, "stock") == "stock"}
    if not eq or "SPY" not in panel.prices:
        return 1.0
    px = panel.prices[list(eq) + ["SPY"]].dropna().iloc[-756:].pct_change().dropna()
    tot = sum(eq.values())
    port = sum(px[t] * x / tot for t, x in eq.items())
    return float(np.clip(port.std() / px["SPY"].std(), 0.6, 2.0))


# --------------------------------------------------------------------------------------
# Monte Carlo (real dollars, 12-month block bootstrap of 1928-2026 history)
# --------------------------------------------------------------------------------------
def monte_carlo(mix: dict, start: float, contrib_m: np.ndarray, n_paths: int = 1000, seed: int = 7,
                fee_bps: float = 10, vol_mult: float = 1.0, hist_start: str = "1928-01-01",
                crash: tuple[str, int] | None = None, shocks: np.ndarray | None = None) -> dict:
    lr = D.longrun().loc[hist_start:]
    X = lr[["stock", "bond", "gold", "cash"]].to_numpy().copy()
    mu = X[:, 0].mean()
    X[:, 0] = mu + vol_mult * (X[:, 0] - mu)
    infl = lr["inflation"].to_numpy()
    T = len(lr)
    M = len(contrib_m)
    rng = np.random.default_rng(seed)
    nb = M // 12 + 1
    st = rng.integers(0, T - 12, size=(n_paths, nb))
    idx = (st[:, :, None] + np.arange(12)).reshape(n_paths, -1)[:, :M]
    if crash:
        s, e = CRASHES[crash[0]]
        pos = np.where((lr.index >= s) & (lr.index <= e))[0]
        m0 = crash[1] * 12
        L = min(len(pos), M - m0)
        if L > 0:
            idx[:, m0:m0 + L] = pos[:L]
    w = np.array([mix["stock"], mix["bond"], mix["gold"], mix["cash"]])
    port = X[idx] @ w - fee_bps / 10000 / 12
    real = (1 + port) / (1 + infl[idx]) - 1
    flows = np.broadcast_to(contrib_m, (n_paths, M)).copy()
    if shocks is not None:
        flows += shocks
    wealth = np.full(n_paths, float(start))
    out = np.zeros((n_paths, M // 12 + 1))
    out[:, 0] = wealth
    for m in range(M):
        g = np.where(wealth >= 0, real[:, m], 0.07 / 12)  # borrowing cost if the plan dips negative
        wealth = wealth * (1 + g) + flows[:, m]
        if (m + 1) % 12 == 0:
            out[:, (m + 1) // 12] = wealth
    pct = {q: np.percentile(out, q, axis=0) for q in (10, 25, 50, 75, 90)}
    return {"paths": out, "pct": pct, "years": np.arange(out.shape[1])}


CRASHES = {
    "2008 Global Financial Crisis": ("2007-10-01", "2009-09-01"),
    "2020 COVID crash": ("2020-02-01", "2020-12-01"),
    "2022 inflation & rate shock": ("2022-01-01", "2022-12-01"),
    "2000-02 dot-com bust": ("2000-09-01", "2002-12-01"),
    "1973-74 oil shock": ("1973-01-01", "1974-12-01"),
}


def expected_real_return(mix: dict) -> float:
    lr = D.longrun()
    real = {c: ((1 + lr[c]) / (1 + lr["inflation"])).prod() ** (12 / len(lr)) - 1 for c in ["stock", "bond", "gold", "cash"]}
    return sum(mix[c] * real[c] for c in real)
