"""Module 1: client profile, life & career paths, human capital, risk tolerance vs capacity."""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from itertools import pairwise
from typing import Any

import numpy as np
import pandas as pd

from . import data as D

CURRENT_YEAR = 2026
SECTOR_GROWTH = {"industry": 0.030, "academe": 0.020, "government": 0.020, "nonprofit": 0.015, "postdoc": 0.03}
# how much a career's earnings move with the stock market (used to tilt the portfolio)
EQUITY_LIKENESS = {"industry": 0.55, "academe": 0.15, "government": 0.10, "nonprofit": 0.25}
TECHY_FIELDS = {"Computer & information sciences", "Engineering", "Mathematics & statistics"}

DEMO: dict[str, Any] = {
    "name": "Mei Chen", "age": 25, "residency": "us", "india_treaty": False, "treaty_exempt": 0,
    "status": "phd", "prospective_program": "masters", "masters_len": 2, "masters_year": 1, "plan_after_masters": "industry",
    "phd_year": 2, "phd_total": 5, "postdoc_years": 2, "p_tenure": 25,
    "field": "Computer & information sciences", "univ_metro": "pit", "target_metro": "sea",
    "target_sector": "industry", "masters_salary": 135000, "phd_salary_override": 0, "salary_growth": 3.0,
    "stipend": 46000, "stipend_type": "wages", "fellowship_share": 0, "summer_income": 9000, "side_income": 0,
    "side_type": "w2", "tuition_covered": True, "tuition_cost": 0, "student_fica_exempt": True, "employer_plan": True,
    "cash": 8000, "roth_ira": 3500, "pretax_ret": 0, "taxable": 1500, "crypto": 0,
    "ug_loan": 12000, "ug_rate": 5.5, "ug_payment": 0, "grad_loan": 0, "grad_rate": 8.07, "new_borrow": 0,
    "cc_debt": 600, "cc_rate": 23.0,
    "rent": 1150, "utilities": 110, "groceries": 380, "dining": 180, "transit": 60, "phone": 45, "health_ins": 0,
    "books": 40, "conferences": 60, "subscriptions": 35, "travel": 120, "personal": 120, "other": 80,
    "ef_months": 4, "laptop_amt": 2200, "laptop_year": 2027, "reloc_amt": 6000, "home_down_pct": 10, "home_year": 2034,
    "q1": "3", "q2": "3", "q3": "2", "q4": "3", "save_rate_after": 20, "retire_age": 65,
}


# Demo personas (shown on the welcome screen)
ARJUN: dict[str, Any] = {
    **DEMO, "name": "Arjun Mehta", "age": 23, "residency": "intl", "india_treaty": True, "treaty_exempt": 0,
    "status": "masters", "masters_len": 1, "masters_year": 1, "plan_after_masters": "industry",
    "field": "Mathematics & statistics", "univ_metro": "nyc", "target_metro": "aus", "target_sector": "industry",
    "masters_salary": 115000, "stipend": 0, "stipend_type": "wages", "summer_income": 0, "side_income": 12000, "side_type": "w2",
    "tuition_covered": False, "tuition_cost": 0, "student_fica_exempt": True, "employer_plan": False,
    "cash": 14000, "roth_ira": 0, "pretax_ret": 0, "taxable": 0, "crypto": 500, "ug_loan": 0, "ug_payment": 0,
    "grad_loan": 0, "new_borrow": 0, "cc_debt": 0, "rent": 1700, "groceries": 350, "dining": 150, "transit": 132,
    "health_ins": 280, "books": 30, "conferences": 0, "travel": 150, "personal": 100, "other": 60,
    "ef_months": 3, "laptop_amt": 0, "reloc_amt": 4000, "home_down_pct": 0, "q1": "2", "q2": "2", "q3": "1", "q4": "3",
    "save_rate_after": 25,
}
SOFIA: dict[str, Any] = {
    **DEMO, "name": "Sofia Alvarez", "age": 27, "residency": "us", "status": "phd", "phd_year": 4, "phd_total": 6,
    "field": "Biological & biomedical sciences", "univ_metro": "bos", "target_metro": "bos", "target_sector": "academe",
    "postdoc_years": 3, "p_tenure": 20, "stipend": 51000, "stipend_type": "fellowship", "summer_income": 0,
    "cash": 6500, "roth_ira": 9000, "taxable": 0, "ug_loan": 22000, "ug_rate": 4.99, "cc_debt": 0,
    "rent": 1650, "dining": 160, "ef_months": 4, "laptop_amt": 0, "reloc_amt": 3000, "home_down_pct": 5, "home_year": 2036,
    "q1": "2", "q2": "2", "q3": "2", "q4": "3", "save_rate_after": 15,
}
DEMOS = {
    "mei": (DEMO, "Mei Chen, 25", "2nd-year Computer Science PhD at Carnegie Mellon (Pittsburgh), aiming for an industry research job in Seattle.", "cpu"),
    "arjun": (ARJUN, "Arjun Mehta, 23", "International student in a 1-year Statistics master's in New York, moving to Austin for a data science job.", "graph-up"),
    "sofia": (SOFIA, "Sofia Alvarez, 27", "4th-year Biology PhD on a fellowship in Boston, weighing a postdoc and a faculty career.", "flower1"),
}


def phd_track(p: dict) -> bool:
    """True if the client is in a PhD/postdoc or plans to start one. PhD-only questions and paths depend on this."""
    st = p["status"]
    if st in ("phd", "postdoc"):
        return True
    if st == "masters":
        return p.get("plan_after_masters") == "phd"
    if st == "prospective":
        return p.get("prospective_program") == "phd" or p.get("plan_after_masters") == "phd"
    return False


def status_text(p: dict) -> str:
    st = p["status"]
    then_phd = " → PhD" if p.get("plan_after_masters") == "phd" else ""
    if st == "prospective":
        return "Starting a PhD" if p.get("prospective_program") == "phd" else f"Starting a {p['masters_len']}-year master's{then_phd}"
    if st == "masters":
        return f"Master's student, year {p['masters_year']} of {p['masters_len']}{then_phd}"
    if st == "phd":
        return f"PhD student, year {p['phd_year']} of {p['phd_total']}"
    return f"Postdoc, {p['postdoc_years']} yr left"


def fields() -> list[str]:
    return list(D.careers()["fields"])


def metro_row(mid: str) -> pd.Series:
    m = D.metros()
    return m.set_index("id").loc[mid]


# --------------------------------------------------------------------------------------
# Wage geography
# --------------------------------------------------------------------------------------
def wage_factor(metro_id: str, field_name: str, sector: str) -> tuple[float, str]:
    """Metro pay relative to the US. Uses BLS OEWS metro wages if refreshed, else BEA price level as a proxy."""
    m = metro_row(metro_id)
    f = D.careers()["fields"][field_name]
    occ = f.get("occ_academic") if sector == "academe" else f.get("occ_industry")
    oews = D.load_oews_metro()
    if occ and oews is not None:
        row = oews[(oews.cbsa == str(int(m.cbsa))) & (oews.soc == occ[0])]
        if len(row) and pd.notna(row.iloc[0].get("annual_mean")):
            return float(row.iloc[0]["annual_mean"]) / occ[2], f"BLS OEWS {occ[1]} in {m['name']}"
    return float(m.rpp) / 100.0, f"BEA price level proxy (RPP {m.rpp:.1f})"


def start_salary(p: dict, sector: str) -> float:
    sed = D.careers()["fields"][p["field"]]["sed"]
    base = sed["postdoc" if sector == "postdoc" else sector]
    if sector == "industry" and p.get("phd_salary_override"):
        base = p["phd_salary_override"]
    return float(base)


def expected_salary(p: dict, sector: str) -> float:
    """National starting salary for the client's credential: SED PhD medians for PhD-track clients,
    otherwise their expected master's salary (scaled by SED sector/industry ratios for non-industry jobs)."""
    if phd_track(p):
        return start_salary(p, sector)
    sed = D.careers()["fields"][p["field"]]["sed"]
    s = sector if sector in ("industry", "government", "nonprofit") else "industry"
    return float(p["masters_salary"]) * (1.0 if s == "industry" else sed[s] / sed["industry"])


# --------------------------------------------------------------------------------------
# Paths
# --------------------------------------------------------------------------------------
@dataclass
class Path:
    key: str
    label: str
    phases: list = field(default_factory=list)       # (start_year_idx, end_year_idx, label, sector)
    income: np.ndarray = None                         # real 2026 $, gross, per year from now
    note: str = ""


def _remaining(p: dict) -> dict:
    st = p["status"]
    out = {"ms": 0, "phd": 0, "postdoc": 0}
    if st == "prospective":
        if p.get("prospective_program") == "phd":
            out["phd"] = p["phd_total"]
        else:
            out["ms"] = p["masters_len"]
            out["phd"] = p["phd_total"]
    elif st == "masters":
        out["ms"] = max(1, p["masters_len"] - p["masters_year"] + 1)
        out["phd"] = p["phd_total"]
    elif st == "phd":
        out["phd"] = max(1, p["phd_total"] - p["phd_year"] + 1)
    elif st == "postdoc":
        out["postdoc"] = max(1, p["postdoc_years"])
    return out


def _career_stream(start: float, n: int, sector: str, g0: float) -> np.ndarray:
    s = np.zeros(n)
    sal = start
    for k in range(n):
        s[k] = sal
        g = g0 * max(0.25, 1 - k / 30)
        if sector == "academe" and k == 6:
            sal *= 1.12  # promotion with tenure
        sal *= 1 + g
    return s


MS_SECTORS = ("industry", "government", "nonprofit")
TYPICAL_PHD_STIPEND = 37000  # NSF GRFP stipend, used for "what if I did a PhD?" comparisons


def build_paths(p: dict, compare_phd: bool = False) -> list[Path]:
    """Career paths to compare. PhD paths appear only for PhD-track clients, or as an opt-in what-if for master's clients."""
    years = max(5, p.get("retire_age", 65) - p["age"])
    rem = _remaining(p)
    stipend = p["stipend"] + p.get("summer_income", 0)
    tuition = 0 if p.get("tuition_covered", True) else p.get("tuition_cost", 0)
    g_user = p.get("salary_growth", 3.0) / 100
    paths: list[Path] = []
    tm = p["target_metro"]
    sed = D.careers()["fields"][p["field"]]["sed"]
    on_phd = phd_track(p)
    in_masters = p["status"] == "masters" or (p["status"] == "prospective" and p.get("prospective_program") != "phd")

    # A) Master's -> work (industry / government / nonprofit); sector pay scaled from your expected master's salary by SED ratios
    if in_masters:
        n = rem["ms"]
        for sector in MS_SECTORS:
            if on_phd and sector != "industry":
                continue  # PhD planners: keep only the 'skip the PhD' comparison
            inc = np.zeros(years)
            inc[:n] = stipend - tuition
            wf, _ = wage_factor(tm, p["field"], sector)
            base = p["masters_salary"] * (1.0 if sector == "industry" else sed[sector] / sed["industry"])
            inc[n:] = _career_stream(base * wf, years - n, sector, g_user if sector == "industry" else SECTOR_GROWTH[sector])
            lab = {"industry": "Master's → Industry", "government": "Master's → Government", "nonprofit": "Master's → Nonprofit"}[sector]
            if on_phd:
                lab = "Skip the PhD: Master's → Industry"
            paths.append(Path(f"ms_{sector}", lab, [(0, n, "Master's", "school"), (n, years, D.careers()["sectors"][sector], sector)], inc,
                              note="" if sector == "industry" else f"Starting pay = your master's salary × SED {sector}/industry ratio ({sed[sector] / sed['industry']:.2f})."))

    if p["status"] == "phd":
        inc = np.zeros(years)
        inc[:1] = stipend
        wf, _ = wage_factor(tm, p["field"], "industry")
        inc[1:] = _career_stream(p["masters_salary"] * wf, years - 1, "industry", g_user)
        paths.append(Path("ms_out", "Leave with a master's → Industry", [(0, 1, "Finish this year", "school"), (1, years, "Industry career", "industry")], inc,
                          note="'Mastering out': finish the current year, collect the en-route master's, start working."))

    if not on_phd and not compare_phd:
        return paths

    what_if = not on_phd
    pre = rem["ms"] if in_masters else 0
    ph = 0 if p["status"] == "postdoc" else rem["phd"]
    school_n = pre + ph
    phd_stipend = max(stipend, TYPICAL_PHD_STIPEND) if what_if else stipend
    prefix = "What if: " if what_if else ""

    def phd_base():
        inc = np.zeros(years)
        inc[:pre] = stipend - tuition
        inc[pre:school_n] = phd_stipend
        ph_ = [(0, pre, "Master's", "school")] if pre else []
        if ph:
            ph_.append((pre, school_n, "PhD", "school"))
        return inc, ph_

    for sector in ("industry", "government", "nonprofit"):
        inc, ph_ = phd_base()
        wf, _ = wage_factor(tm, p["field"], sector)
        inc[school_n:] = _career_stream(start_salary(p, sector) * wf, years - school_n, sector,
                                        g_user if sector == "industry" else SECTOR_GROWTH[sector])
        lab = {"industry": "PhD → Industry", "government": "PhD → Government / lab", "nonprofit": "PhD → Nonprofit / institute"}[sector]
        paths.append(Path(f"phd_{sector}", prefix + lab, ph_ + [(school_n, years, D.careers()["sectors"][sector], sector)], inc,
                          note=f"Assumes a funded {ph}-year PhD at about ${phd_stipend:,.0f}/yr." if what_if and sector == "industry" else ""))

    # Academia: postdoc, then tenure-track with probability p, else switch to industry
    inc, ph_ = phd_base()
    pdn = p["postdoc_years"] if p["status"] != "postdoc" else rem["postdoc"]
    wf_a, _ = wage_factor(tm, p["field"], "academe")
    wf_i, _ = wage_factor(tm, p["field"], "industry")
    inc[school_n:school_n + pdn] = _career_stream(start_salary(p, "postdoc") * wf_a, pdn, "postdoc", 0.03)
    k0 = school_n + pdn
    prob = p["p_tenure"] / 100
    acad = _career_stream(start_salary(p, "academe") * wf_a, years - k0, "academe", SECTOR_GROWTH["academe"])
    alt = _career_stream(start_salary(p, "industry") * wf_i * 0.9, years - k0, "industry", g_user)  # late-switch discount
    inc[k0:] = prob * acad + (1 - prob) * alt
    paths.append(Path("phd_acad", prefix + "PhD → Postdoc → Academia", ph_ + [(school_n, k0, "Postdoc", "postdoc"),
                                                                               (k0, years, f"Faculty ({p['p_tenure']:.0f}%) / industry fallback", "academe")],
                      inc, note=f"Expected value: {p['p_tenure']:.0f}% chance of a tenure-track job, otherwise an industry job at a 10% late-switch discount."))
    return paths


def path_metrics(path: Path, p: dict, discount: float = 0.04) -> dict:
    t = np.arange(len(path.income))
    pv = float(np.sum(path.income / (1 + discount) ** t))
    life = float(path.income.sum())
    first_job = next((ph for ph in path.phases if ph[3] not in ("school",)), None)
    start = float(path.income[first_job[0]]) if first_job and first_job[0] < len(path.income) else 0.0
    return {"pv": pv, "lifetime": life, "start_salary": start, "peak": float(path.income.max()),
            "years_in_school": sum(ph[1] - ph[0] for ph in path.phases if ph[3] == "school")}


def breakeven_age(a: Path, b: Path, age: int) -> int | None:
    """Age at which cumulative earnings of path a overtake path b (None if never)."""
    diff = np.cumsum(a.income - b.income)
    neg = np.where(diff < 0)[0]
    if not len(neg):
        return age
    last_neg = neg[-1]
    if last_neg >= len(diff) - 1:
        return None
    return age + int(last_neg) + 1


def selected_path(p: dict, paths: list[Path]) -> Path:
    sector = p["target_sector"]
    if not phd_track(p):
        key = f"ms_{sector if sector in MS_SECTORS else 'industry'}"
    else:
        key = {"industry": "phd_industry", "academe": "phd_acad", "government": "phd_government", "nonprofit": "phd_nonprofit"}[sector]
    return next(x for x in paths if x.key == key)


# --------------------------------------------------------------------------------------
# Absolute & relative profile
# --------------------------------------------------------------------------------------
def assets(p: dict) -> float:
    return p["cash"] + p["roth_ira"] + p["pretax_ret"] + p["taxable"] + p["crypto"]


def debts(p: dict) -> float:
    return p["ug_loan"] + p["grad_loan"] + p["cc_debt"]


def net_worth(p: dict) -> float:
    return assets(p) - debts(p)


def scf_percentile(nw: float, age: int) -> tuple[float, dict]:
    b = D.rules()["benchmarks"]
    row = b["scf_under_35"] if age < 35 else b["scf_35_44"]
    pts = [(10, row["p10"]), (25, row["p25"]), (50, row["p50"]), (75, row["p75"]), (90, row["p90"])]
    if nw <= pts[0][1]:
        return max(1.0, 10 * (1 - (pts[0][1] - nw) / (abs(pts[0][1]) + 1e4))), row
    if nw >= pts[-1][1]:
        return min(99.0, 90 + 9 * (1 - math.exp(-(nw - pts[-1][1]) / pts[-1][1]))), row
    for (p0, v0), (p1, v1) in pairwise(pts):
        if v0 <= nw <= v1:
            return p0 + (p1 - p0) * (nw - v0) / (v1 - v0), row
    return 50.0, row


def stipend_power(p: dict) -> dict:
    """Stipend in national-average dollars vs the NSF GRFP benchmark."""
    m = metro_row(p["univ_metro"])
    real = p["stipend"] / (m.rpp / 100)
    grfp = D.rules()["benchmarks"]["grfp_stipend"]
    return {"real": real, "grfp": grfp, "ratio": real / grfp, "rpp": float(m.rpp), "metro": m["name"]}


def risk_tolerance(p: dict) -> float:
    v = [int(p[k]) for k in ("q1", "q2", "q3", "q4")]
    return round(1 + 9 * (sum(v) - 4) / 12, 1)


def risk_capacity(p: dict, ef_months: float, hc_pv: float, sector: str) -> float:
    horizon = max(0, p.get("retire_age", 65) - p["age"])
    s_h = min(horizon / 40, 1.0)
    s_ef = min(ef_months / 6, 1.0)
    s_debt = 0.0 if p["cc_debt"] > 500 else 1.0
    s_stab = 1 - EQUITY_LIKENESS[sector]
    s_hc = min(hc_pv / 1.5e6, 1.0)  # lots of future earnings = can afford market risk
    return round(1 + 9 * (0.35 * s_h + 0.2 * s_ef + 0.15 * s_debt + 0.15 * s_stab + 0.15 * s_hc), 1)


def recommended_equity(tol: float, cap: float, p: dict, sector: str) -> dict:
    score = min(0.5 * tol + 0.5 * cap, cap + 1.0)
    base = 0.30 + (score - 1) / 9 * 0.65
    adj = -0.10 * EQUITY_LIKENESS[sector] + 0.05 * (1 - EQUITY_LIKENESS[sector]) - 0.0
    eq = float(np.clip(base + adj - 0.01 * max(0, p["age"] - 40), 0.25, 0.95))
    return {"score": round(score, 1), "equity": eq, "base": base, "hc_adj": adj,
            "field_hedge": p["field"] in TECHY_FIELDS and sector == "industry"}
