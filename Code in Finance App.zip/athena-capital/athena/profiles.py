"""Save, load and delete client profiles (JSON files in ./profiles)."""
from __future__ import annotations

import json
import re
from datetime import datetime
from pathlib import Path

DIR = Path(__file__).resolve().parents[1] / "profiles"
DIR.mkdir(exist_ok=True)


def _slug(name: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", (name or "client").lower()).strip("-") or "client"


def list_profiles() -> dict[str, str]:
    out = {}
    for f in sorted(DIR.glob("*.json")):
        try:
            d = json.loads(f.read_text())
            out[f.stem] = f"{d.get('name', f.stem)} · saved {d.get('_saved_at', '')[:10]}"
        except Exception:
            continue
    return out


def save(p: dict) -> str:
    slug = _slug(p.get("name"))
    (DIR / f"{slug}.json").write_text(json.dumps({**p, "_saved_at": datetime.now().isoformat(timespec="seconds")}, indent=2, default=str))
    return slug


def load(slug: str) -> dict:
    d = json.loads((DIR / f"{slug}.json").read_text())
    return {k: v for k, v in d.items() if not k.startswith("_")}


def delete(slug: str) -> None:
    f = DIR / f"{slug}.json"
    if f.exists():
        f.unlink()
