"""
Data layer for Athena Capital.

Three tiers, so the demo never depends on a live connection:
  1. data/reference/*.json   hand-verified reference tables (sources cited inside each file)
  2. data/bundled/*.csv      public datasets snapshotted from github.com/datasets (Shiller, CPI, 10y yields, gold, VIX, Case-Shiller)
  3. data/cache/*            live data pulled on YOUR machine (Yahoo Finance ETFs, BLS metro wages, FRED housing,
                             Google News, RentCast listings, WRDS CRSP/Fama-French). Refresh in-app or with
                             `python scripts/refresh_data.py`; every fetcher falls back to the last cached copy.
"""
from __future__ import annotations

import json
import os
import time
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from urllib.parse import quote_plus

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
REF = ROOT / "data" / "reference"
BUNDLED = ROOT / "data" / "bundled"
CACHE = ROOT / "data" / "cache"
CACHE.mkdir(parents=True, exist_ok=True)

UA = {"User-Agent": "Mozilla/5.0 (AthenaCapital educational app)"}


# --------------------------------------------------------------------------------------
# Reference tables
# --------------------------------------------------------------------------------------
@lru_cache(maxsize=None)
def ref(name: str) -> dict:
    return json.loads((REF / f"{name}.json").read_text())


def metros() -> pd.DataFrame:
    df = pd.DataFrame(ref("metros")["metros"])
    live = load_fred_housing()
    if live is not None and not live.empty:
        last = live.ffill().iloc[-1]
        for i, r in df.iterrows():
            col = f"MEDLISPRI{r.cbsa}"
            if col in last and pd.notna(last[col]) and pd.isna(r.list_price):
                df.at[i, "list_price"] = float(last[col])
    return df


def careers() -> dict:
    return ref("careers")


def rules() -> dict:
    return ref("tax_rules_2026")


# --------------------------------------------------------------------------------------
# ETF universe for the Portfolio Studio
# --------------------------------------------------------------------------------------
ETFS: dict[str, dict] = {
    # core US equity by size x style
    "VTI": {"name": "US Total Stock Market", "group": "US equity", "size": "Total", "style": "Blend"},
    "VOO": {"name": "US Large Cap (S&P 500)", "group": "US equity", "size": "Large", "style": "Blend"},
    "VUG": {"name": "US Large Growth", "group": "US equity", "size": "Large", "style": "Growth"},
    "VTV": {"name": "US Large Value", "group": "US equity", "size": "Large", "style": "Value"},
    "VO": {"name": "US Mid Cap", "group": "US equity", "size": "Mid", "style": "Blend"},
    "VOT": {"name": "US Mid Growth", "group": "US equity", "size": "Mid", "style": "Growth"},
    "VOE": {"name": "US Mid Value", "group": "US equity", "size": "Mid", "style": "Value"},
    "VB": {"name": "US Small Cap", "group": "US equity", "size": "Small", "style": "Blend"},
    "VBK": {"name": "US Small Growth", "group": "US equity", "size": "Small", "style": "Growth"},
    "VBR": {"name": "US Small Value", "group": "US equity", "size": "Small", "style": "Value"},
    "ESGU": {"name": "US ESG-screened", "group": "US equity", "size": "Large", "style": "ESG"},
    "SCHD": {"name": "US Dividend", "group": "Theme", "size": "Large", "style": "Value"},
    "QQQ": {"name": "Nasdaq-100", "group": "Theme", "size": "Large", "style": "Growth"},
    # international
    "VEA": {"name": "Developed ex-US", "group": "International"},
    "VWO": {"name": "Emerging Markets", "group": "International"},
    "VXUS": {"name": "Total International", "group": "International"},
    # fixed income & real assets
    "BND": {"name": "US Aggregate Bonds", "group": "Bonds"},
    "SHY": {"name": "Short Treasuries (1-3y)", "group": "Bonds"},
    "TLT": {"name": "Long Treasuries (20y+)", "group": "Bonds"},
    "TIP": {"name": "TIPS (inflation-protected)", "group": "Bonds"},
    "BNDX": {"name": "International Bonds (hedged)", "group": "Bonds"},
    "BIL": {"name": "T-Bills (cash)", "group": "Cash"},
    "VNQ": {"name": "US Real Estate (REITs)", "group": "Real assets"},
    "GLD": {"name": "Gold", "group": "Real assets"},
    # GICS sectors (SPDR)
    "XLK": {"name": "Technology", "group": "Sector"},
    "XLV": {"name": "Health Care", "group": "Sector"},
    "XLF": {"name": "Financials", "group": "Sector"},
    "XLE": {"name": "Energy", "group": "Sector"},
    "XLI": {"name": "Industrials", "group": "Sector"},
    "XLY": {"name": "Consumer Discretionary", "group": "Sector"},
    "XLP": {"name": "Consumer Staples", "group": "Sector"},
    "XLU": {"name": "Utilities", "group": "Sector"},
    "XLB": {"name": "Materials", "group": "Sector"},
    "XLRE": {"name": "Real Estate", "group": "Sector"},
    "XLC": {"name": "Communication Services", "group": "Sector"},
    # themes
    "SOXX": {"name": "Semiconductors", "group": "Theme"},
    "IBB": {"name": "Biotechnology", "group": "Theme"},
    "ICLN": {"name": "Clean Energy", "group": "Theme"},
    "SPY": {"name": "S&P 500 (benchmark)", "group": "Benchmark"},
}

# long-run proxy used for Monte Carlo and when no ETF cache exists
ETF_PROXY = {"BND": "bond", "SHY": "cash", "TLT": "bond", "TIP": "bond", "BNDX": "bond", "BIL": "cash", "GLD": "gold"}


def etf_label(t: str) -> str:
    return f"{t} · {ETFS.get(t, {}).get('name', t)}"


# --------------------------------------------------------------------------------------
# Bundled long-run monthly series (Shiller + CPI + 10y + gold), through Sep 2026
# --------------------------------------------------------------------------------------
def _par_bond_return(y0: float, y1: float, years: float = 10.0) -> float:
    c, r, n = y0 / 2, y1 / 2, round((years - 1 / 12) * 2)
    price = c * (1 - (1 + r) ** -n) / r + (1 + r) ** -n if r > 0 else c * n + 1
    return price - 1 + y0 / 12


@lru_cache(maxsize=1)
def longrun() -> pd.DataFrame:
    """Monthly returns: stock (S&P 500 total return), bond (10y par Treasury), gold, cash proxy, inflation."""
    sp = pd.read_csv(BUNDLED / "s-and-p-500.csv", parse_dates=["Date"]).set_index("Date").sort_index()
    sp = sp[sp["SP500"] > 0]
    div = sp["Dividend"].where(sp["Dividend"] > 0)
    last_full = div.last_valid_index()
    yld = (div / sp["SP500"]).loc[:last_full].iloc[-12:].mean()
    div = div.fillna(sp["SP500"] * yld)  # after Shiller's last dividend: hold the trailing 12m yield
    stock = (sp["SP500"] + div / 12) / sp["SP500"].shift(1) - 1

    y = sp["Long Interest Rate"].where(sp["Long Interest Rate"] > 0) / 100
    b10 = pd.read_csv(BUNDLED / "bond-yields-us-10y.csv", parse_dates=["Date"]).set_index("Date")["Rate"] / 100
    y = y.combine_first(b10).sort_index()
    y = y.reindex(sp.index).ffill()
    bond = pd.Series([np.nan] + [_par_bond_return(y.iloc[i - 1], y.iloc[i]) for i in range(1, len(y))], index=y.index)

    cpi = pd.read_csv(BUNDLED / "cpi-us.csv", parse_dates=["Date"]).set_index("Date")["Index"]
    infl = cpi.pct_change()

    gold = pd.read_csv(BUNDLED / "gold-prices.csv")
    gold["Date"] = pd.to_datetime(gold["Date"])
    gold = gold.set_index("Date")["Price"].pct_change()

    df = pd.DataFrame({"stock": stock, "bond": bond}).join(infl.rename("inflation"), how="left").join(gold.rename("gold"), how="left")
    df["cash"] = df["inflation"].rolling(12, min_periods=1).mean() + 0.005 / 12  # assumption: T-bills ~ inflation + 0.5%/yr
    df = df.loc["1928-01-01":].dropna(subset=["stock", "bond", "inflation"])
    df["gold"] = df["gold"].fillna(0.0)
    return df


def longrun_end() -> pd.Timestamp:
    return longrun().index[-1]


@lru_cache(maxsize=1)
def vix() -> pd.Series:
    v = pd.read_csv(BUNDLED / "finance-vix.csv", parse_dates=["DATE"]).set_index("DATE")["CLOSE"]
    return v


@lru_cache(maxsize=1)
def case_shiller() -> pd.Series:
    return pd.read_csv(BUNDLED / "house-prices-us.csv", parse_dates=["Date"]).set_index("Date")["National-US"]


@lru_cache(maxsize=1)
def sp500_sectors() -> pd.DataFrame:
    return pd.read_csv(BUNDLED / "s-and-p-500-companies.csv")


# --------------------------------------------------------------------------------------
# Cache helpers
# --------------------------------------------------------------------------------------
def cache_age_hours(path: Path) -> float | None:
    return (time.time() - path.stat().st_mtime) / 3600 if path.exists() else None


def cache_stamp(path: Path) -> str:
    if not path.exists():
        return "not downloaded yet"
    return time.strftime("%b %d, %Y %H:%M", time.localtime(path.stat().st_mtime))


# --------------------------------------------------------------------------------------
# Live: ETF prices (Yahoo Finance via yfinance)  -> data/cache/etf_prices.csv
# --------------------------------------------------------------------------------------
ETF_CACHE = CACHE / "etf_prices.csv"


def refresh_etf_prices(period: str = "15y") -> tuple[bool, str]:
    try:
        import yfinance as yf
        raw = yf.download(list(ETFS), period=period, interval="1d", auto_adjust=True, progress=False, threads=True)
        if raw is None or raw.empty:
            return False, "Yahoo Finance returned no data (check your internet connection)."
        close = raw["Close"] if isinstance(raw.columns, pd.MultiIndex) else raw[["Close"]]
        close = close.dropna(how="all")
        close.index.name = "date"
        close.to_csv(ETF_CACHE)
        load_etf_prices.cache_clear()
        return True, f"Downloaded {close.shape[1]} ETFs, {close.index[0]:%b %Y}-{close.index[-1]:%b %d, %Y}."
    except Exception as e:  # pragma: no cover - network dependent
        return False, f"ETF refresh failed: {e}"


@lru_cache(maxsize=1)
def load_etf_prices() -> pd.DataFrame | None:
    if not ETF_CACHE.exists():
        return None
    df = pd.read_csv(ETF_CACHE, parse_dates=["date"]).set_index("date").sort_index()
    return df.dropna(how="all")


@lru_cache(maxsize=1)
def load_crsp_monthly() -> pd.DataFrame | None:
    f = CACHE / "wrds_crsp_monthly.csv"
    if not f.exists():
        return None
    df = pd.read_csv(f, parse_dates=["date"]).set_index("date").sort_index()
    return df


@lru_cache(maxsize=1)
def load_ff_factors() -> pd.DataFrame | None:
    f = CACHE / "wrds_ff_factors.csv"
    if not f.exists():
        return None
    df = pd.read_csv(f, parse_dates=["date"])
    df["date"] = df["date"].dt.to_period("M").dt.to_timestamp()
    df = df.set_index("date")
    if df["rf"].abs().max() > 0.2:  # percent units guard
        df = df / 100
    return df


# --------------------------------------------------------------------------------------
# Live: BLS OEWS metro wages (public API)  -> data/cache/oews_metro.csv
# --------------------------------------------------------------------------------------
OEWS_CACHE = CACHE / "oews_metro.csv"


def _oews_series(cbsa: str, soc: str, datatype: str) -> str:
    # OEU + M (metro) + 7-digit area + 000000 (all industries) + 6-digit SOC + 2-digit datatype
    return f"OEUM{int(cbsa):07d}000000{soc.replace('-', '')}{datatype}"


def refresh_oews_metro(socs: list[str] | None = None) -> tuple[bool, str]:
    import requests
    socs = socs or sorted({v["occ_industry"][0] for v in careers()["fields"].values() if v.get("occ_industry")} |
                          {v["occ_academic"][0] for v in careers()["fields"].values() if v.get("occ_academic")} |
                          set(careers()["oews_extra"]))
    ms = ref("metros")["metros"]
    series = []
    for m in ms:
        for s in socs:
            series += [_oews_series(m["cbsa"], s, "04"), _oews_series(m["cbsa"], s, "01")]
    key = os.environ.get("BLS_API_KEY")
    url = "https://api.bls.gov/publicAPI/v2/timeseries/data/"
    batch = 50 if key else 25
    rows = []
    try:
        for i in range(0, len(series), batch):
            payload = {"seriesid": series[i:i + batch], "latest": True}
            if key:
                payload["registrationkey"] = key
            r = requests.post(url, json=payload, headers=UA, timeout=30)
            js = r.json()
            if js.get("status") != "REQUEST_SUCCEEDED":
                if rows:
                    break
                return False, "BLS API: " + "; ".join(js.get("message", [])[:2])
            for s in js["Results"]["series"]:
                sid = s["seriesID"]
                if not s["data"]:
                    continue
                d = s["data"][0]
                v = d["value"].replace(",", "")
                if v in ("-", "*", "#", ""):
                    continue
                rows.append({"cbsa": str(int(sid[4:11])), "soc": sid[17:19] + "-" + sid[19:23], "datatype": sid[23:25],
                             "year": d["year"], "value": float(v)})
        if not rows:
            return False, "BLS API returned no metro data."
        df = pd.DataFrame(rows).pivot_table(index=["cbsa", "soc", "year"], columns="datatype", values="value").reset_index()
        df = df.rename(columns={"04": "annual_mean", "01": "employment"})
        df.to_csv(OEWS_CACHE, index=False)
        load_oews_metro.cache_clear()
        return True, f"BLS OEWS: {len(df)} metro x occupation rows (May {df.year.max()})."
    except Exception as e:  # pragma: no cover
        return False, f"BLS refresh failed: {e}"


@lru_cache(maxsize=1)
def load_oews_metro() -> pd.DataFrame | None:
    if not OEWS_CACHE.exists():
        return None
    df = pd.read_csv(OEWS_CACHE, dtype={"cbsa": str})
    return df


# --------------------------------------------------------------------------------------
# Live: FRED (Realtor.com median listing price by metro, monthly)  -> data/cache/fred_housing.csv
# --------------------------------------------------------------------------------------
FRED_CACHE = CACHE / "fred_housing.csv"


def refresh_fred_housing() -> tuple[bool, str]:
    import io

    import requests
    frames = []
    try:
        for m in ref("metros")["metros"]:
            sid = f"MEDLISPRI{m['cbsa']}"
            r = requests.get(f"https://fred.stlouisfed.org/graph/fredgraph.csv?id={sid}", headers=UA, timeout=20)
            if r.status_code != 200 or "DATE" not in r.text.upper()[:40]:
                continue
            s = pd.read_csv(io.StringIO(r.text))
            s.columns = ["date", sid]
            s["date"] = pd.to_datetime(s["date"])
            s[sid] = pd.to_numeric(s[sid], errors="coerce")
            frames.append(s.set_index("date"))
        if not frames:
            return False, "FRED returned no housing series."
        df = pd.concat(frames, axis=1).sort_index()
        df.to_csv(FRED_CACHE)
        load_fred_housing.cache_clear()
        return True, f"FRED: {df.shape[1]} metro listing-price series through {df.index[-1]:%b %Y}."
    except Exception as e:  # pragma: no cover
        return False, f"FRED refresh failed: {e}"


@lru_cache(maxsize=1)
def load_fred_housing() -> pd.DataFrame | None:
    if not FRED_CACHE.exists():
        return None
    return pd.read_csv(FRED_CACHE, parse_dates=["date"]).set_index("date")


# --------------------------------------------------------------------------------------
# Live: Google News RSS  -> data/cache/news_<slug>.json
# --------------------------------------------------------------------------------------
def _news_path(query: str) -> Path:
    slug = "".join(ch if ch.isalnum() else "_" for ch in query.lower())[:60]
    return CACHE / f"news_{slug}.json"


def parse_rss(xml_text: str, limit: int = 12) -> list[dict]:
    import xml.etree.ElementTree as ET
    from email.utils import parsedate_to_datetime
    out = []
    root = ET.fromstring(xml_text)
    for item in root.iter("item"):
        title = (item.findtext("title") or "").strip()
        link = (item.findtext("link") or "").strip()
        pub = item.findtext("pubDate") or ""
        src_el = item.find("source")
        src = src_el.text.strip() if src_el is not None and src_el.text else ""
        if src and title.endswith(" - " + src):
            title = title[: -(len(src) + 3)]
        try:
            ts = parsedate_to_datetime(pub).timestamp()
        except Exception:
            ts = 0
        out.append({"title": title, "link": link, "source": src, "ts": ts})
        if len(out) >= limit:
            break
    return out


def get_news(query: str, max_age_hours: float = 3.0, force: bool = False) -> tuple[list[dict], str]:
    """Returns (items, status). Uses cache if fresh; falls back to stale cache when offline."""
    path = _news_path(query)
    age = cache_age_hours(path)
    if not force and age is not None and age < max_age_hours:
        return json.loads(path.read_text()), f"cached {age:.1f}h ago"
    try:
        import requests
        url = f"https://news.google.com/rss/search?q={quote_plus(query)}&hl=en-US&gl=US&ceid=US:en"
        r = requests.get(url, headers=UA, timeout=12)
        r.raise_for_status()
        items = parse_rss(r.text)
        path.write_text(json.dumps(items))
        return items, "live from Google News"
    except Exception:
        if path.exists():
            return json.loads(path.read_text()), f"offline: showing cache from {cache_stamp(path)}"
        return [], "offline and no cached headlines yet"


# --------------------------------------------------------------------------------------
# Live (optional API key): RentCast listings  -> data/cache/listings_<city>_<mode>.json
# --------------------------------------------------------------------------------------
@lru_cache(maxsize=1)
def zip_housing() -> pd.DataFrame:
    """Neighborhood (ZIP-code) rents, home values and listing activity around every metro in the app.
    HUD FY2026 Small Area FMRs, Zillow ZORI/ZHVI (Mar 2026), Realtor.com ZIP inventory (Mar 2026); see zip_housing_sources.json."""
    return pd.read_csv(BUNDLED / "zip_housing.csv", dtype={"zip": str})


@lru_cache(maxsize=1)
def zip_housing_meta() -> dict:
    return json.loads((BUNDLED / "zip_housing_sources.json").read_text())


def rentcast_key(user_key: str | None = None) -> str | None:
    """Key typed in the app for this session, else the RENTCAST_API_KEY environment variable. Never written to disk."""
    return (user_key or "").strip() or os.environ.get("RENTCAST_API_KEY") or None


def get_listings(city: str, state: str, mode: str, api_key: str | None, max_price: float | None = None,
                 beds: int | None = None, limit: int = 60, force: bool = False) -> tuple[list[dict], str]:
    path = CACHE / f"listings_{city.replace(' ', '_').lower()}_{state.lower()}_{mode}.json"
    age = cache_age_hours(path)
    if not force and age is not None and age < 24:
        items = json.loads(path.read_text())
        return _filter_listings(items, max_price, beds), f"RentCast listings saved {age:.1f}h ago"
    if not api_key:
        if path.exists():
            return _filter_listings(json.loads(path.read_text()), max_price, beds), f"saved RentCast listings from {cache_stamp(path)}"
        return [], "no key"
    try:
        import requests
        ep = "sale" if mode == "buy" else "rental/long-term"
        r = requests.get(f"https://api.rentcast.io/v1/listings/{ep}",
                         params={"city": city, "state": state, "status": "Active", "limit": limit},
                         headers={"X-Api-Key": api_key, "accept": "application/json"}, timeout=20)
        r.raise_for_status()
        raw = r.json()
        items = [{"address": x.get("formattedAddress"), "lat": x.get("latitude"), "lon": x.get("longitude"),
                  "price": x.get("price"), "beds": x.get("bedrooms"), "baths": x.get("bathrooms"),
                  "sqft": x.get("squareFootage"), "type": x.get("propertyType"), "listed": x.get("listedDate"),
                  "dom": x.get("daysOnMarket")} for x in raw if x.get("latitude") and x.get("price")]
        path.write_text(json.dumps(items))
        return _filter_listings(items, max_price, beds), f"live from RentCast ({len(items)} listings)"
    except Exception as e:  # pragma: no cover
        why = _rentcast_error(e)
        if path.exists():
            return _filter_listings(json.loads(path.read_text()), max_price, beds), f"{why}; showing listings saved {cache_stamp(path)}"
        return [], why


def _rentcast_error(e: Exception) -> str:
    import requests
    if isinstance(e, requests.HTTPError) and e.response is not None:
        code = e.response.status_code
        if code in (401, 403):
            return "RentCast rejected the API key (check it at app.rentcast.io)"
        if code == 429:
            return "RentCast's request limit for this key is used up"
        return f"RentCast returned an error (HTTP {code})"
    if isinstance(e, (requests.ConnectionError, requests.Timeout)):
        return "couldn't reach RentCast (check your internet connection)"
    return f"RentCast error ({type(e).__name__})"


def _filter_listings(items, max_price, beds):
    out = items
    if max_price:
        out = [x for x in out if x["price"] and x["price"] <= max_price]
    if beds:
        out = [x for x in out if (x.get("beds") or 0) >= beds]
    return out


# --------------------------------------------------------------------------------------
# Status summary for the Methods tab
# --------------------------------------------------------------------------------------
@dataclass
class SourceStatus:
    name: str
    status: str
    ok: bool


def data_status() -> list[SourceStatus]:
    lr = longrun()
    etf = load_etf_prices()
    out = [
        SourceStatus("Long-run market history (Shiller S&P 500, CPI, 10y Treasury, gold)", f"bundled, {lr.index[0]:%Y}-{lr.index[-1]:%b %Y}", True),
        SourceStatus("ETF daily prices (Yahoo Finance)", f"{etf.shape[1]} ETFs through {etf.index[-1]:%b %d, %Y}" if etf is not None else "not downloaded: click Update market data (Portfolio Studio)", etf is not None),
        SourceStatus("WRDS CRSP monthly ETF returns", cache_stamp(CACHE / "wrds_crsp_monthly.csv"), (CACHE / "wrds_crsp_monthly.csv").exists()),
        SourceStatus("WRDS Fama-French factors", cache_stamp(CACHE / "wrds_ff_factors.csv"), (CACHE / "wrds_ff_factors.csv").exists()),
        SourceStatus("BLS OEWS metro wages (API)", cache_stamp(OEWS_CACHE), OEWS_CACHE.exists()),
        SourceStatus("FRED / Realtor.com metro listing prices", cache_stamp(FRED_CACHE), FRED_CACHE.exists()),
        SourceStatus("Neighborhood housing by ZIP (HUD FY2026 SAFMR, Zillow Mar 2026, Realtor.com Mar 2026)", f"bundled, {len(zip_housing()):,} ZIP codes", True),
        SourceStatus("Reference tables (SED 2024, OEWS May 2025, BEA RPP 2024, Realtor.com Sep 2026, IRS 2026, Tax Foundation 2026)", "bundled", True),
    ]
    return out
