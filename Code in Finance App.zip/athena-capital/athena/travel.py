"""Travel planner (flight/train deep links, time & budget estimates) and the deals / cash-back toolkit."""
from __future__ import annotations

import math
from typing import Any
from urllib.parse import quote

import pandas as pd

from . import data as D

EXTRA_PLACES = {  # destination name: (lat, lon, airport, country)
    "Honolulu, HI": (21.31, -157.86, "HNL", "US"), "Las Vegas, NV": (36.17, -115.14, "LAS", "US"),
    "New Orleans, LA": (29.95, -90.07, "MSY", "US"), "Orlando, FL": (28.54, -81.38, "MCO", "US"),
    "Providence, RI": (41.82, -71.41, "PVD", "US"), "Toronto, Canada": (43.65, -79.38, "YYZ", "CA"),
    "Vancouver, Canada": (49.28, -123.12, "YVR", "CA"), "Montreal, Canada": (45.50, -73.57, "YUL", "CA"),
    "Mexico City, Mexico": (19.43, -99.13, "MEX", "MX"), "London, UK": (51.51, -0.13, "LHR", "GB"),
    "Paris, France": (48.86, 2.35, "CDG", "FR"), "Berlin, Germany": (52.52, 13.40, "BER", "DE"),
    "Amsterdam, Netherlands": (52.37, 4.90, "AMS", "NL"), "Tokyo, Japan": (35.68, 139.69, "HND", "JP"),
    "Seoul, South Korea": (37.57, 126.98, "ICN", "KR"), "Beijing, China": (39.90, 116.40, "PEK", "CN"),
    "Shanghai, China": (31.23, 121.47, "PVG", "CN"), "Delhi, India": (28.61, 77.21, "DEL", "IN"),
    "Mumbai, India": (19.08, 72.88, "BOM", "IN"), "Singapore": (1.35, 103.82, "SIN", "SG"),
    "Sao Paulo, Brazil": (-23.55, -46.63, "GRU", "BR"), "Ho Chi Minh City, Vietnam": (10.82, 106.63, "SGN", "VN"),
}

# Intercity rail corridors where the train is a realistic option (Amtrak service between members)
RAIL_GROUPS = [
    {"bos", "nyc", "phl", "bal", "dc", "nh", "Providence, RI"},      # Northeast Corridor
    {"nyc", "phl", "pit"},                                          # Keystone / Pennsylvanian
    {"sea", "pdx", "Vancouver, Canada"},                            # Amtrak Cascades
    {"la", "sd"},                                                   # Pacific Surfliner
    {"chi", "aa", "cu", "msn", "msp"},                              # Chicago hub (Wolverine, Illini; Madison via Thruway bus)
    {"ral", "dur", "dc", "nyc"},                                    # Carolinian
    {"nyc", "Montreal, Canada", "Toronto, Canada"},                 # Adirondack / Maple Leaf
]


def places() -> dict[str, dict]:
    out = {}
    for _, r in D.metros().iterrows():
        out[r["name"]] = {"id": r.id, "lat": r.lat, "lon": r.lon, "airport": r.airport, "country": "US"}
    for k, (lat, lon, ap, cc) in EXTRA_PLACES.items():
        out[k] = {"id": k, "lat": lat, "lon": lon, "airport": ap, "country": cc}
    return out


def haversine_mi(a, b) -> float:
    R = 3958.8
    la1, lo1, la2, lo2 = map(math.radians, (a["lat"], a["lon"], b["lat"], b["lon"]))
    h = math.sin((la2 - la1) / 2) ** 2 + math.cos(la1) * math.cos(la2) * math.sin((lo2 - lo1) / 2) ** 2
    return 2 * R * math.asin(math.sqrt(h))


def trip_estimate(origin: str, dest: str) -> dict:
    P = places()
    a, b = P[origin], P[dest]
    d = haversine_mi(a, b)
    rail = any(a["id"] in g and b["id"] in g for g in RAIL_GROUPS) and d < 650
    fly_h = 2.5 + 0.5 + d / 480  # security/boarding/ground + taxi + cruise (heuristic)
    train_h = d / 55 + 0.5 if rail else None
    drive_h = d * 1.2 / 58 if a["country"] == b["country"] == "US" and d < 900 else None
    best = "train" if rail and train_h and train_h <= fly_h + 1.5 else ("drive" if drive_h and drive_h < 4 else "fly")
    return {"miles": d, "rail": rail, "fly_h": fly_h, "train_h": train_h, "drive_h": drive_h, "best": best,
            "a": a, "b": b, "intl": b["country"] != "US" or a["country"] != "US"}


def booking_links(origin: str, dest: str, depart, ret, travelers: int = 1) -> list[tuple[str, str, str]]:
    P = places()
    o, d = P[origin]["airport"], P[dest]["airport"]
    dd = depart.strftime("%Y-%m-%d")
    rr = ret.strftime("%Y-%m-%d") if ret else None
    oc, dc = origin.split(",")[0], dest.split(",")[0]
    links = [
        ("Google Flights", "flight", f"https://www.google.com/travel/flights?q={quote(f'Flights from {o} to {d} on {dd}' + (f' returning {rr}' if rr else ''))}"),
        ("Kayak", "flight", f"https://www.kayak.com/flights/{o}-{d}/{dd}" + (f"/{rr}" if rr else "") + (f"/{travelers}adults" if travelers > 1 else "") + "?sort=price_a"),
        ("Skyscanner", "flight", f"https://www.skyscanner.com/transport/flights/{o.lower()}/{d.lower()}/{depart:%y%m%d}/" + (f"{ret:%y%m%d}/" if ret else "")),
        ("Amtrak", "train", "https://www.amtrak.com/home"),
        ("Wanderu (bus + train)", "train", f"https://www.wanderu.com/en-us/depart/{quote(oc)}/arrive/{quote(dc)}/?departDate={dd}"),
        ("Rome2Rio (all options)", "any", f"https://www.rome2rio.com/map/{quote(oc)}/{quote(dc)}"),
        ("Google Hotels", "stay", f"https://www.google.com/travel/hotels/{quote(dc)}?q={quote('hotels in ' + dc)}"),
    ]
    return links


# --------------------------------------------------------------------------------------
# Deals & cash back
# --------------------------------------------------------------------------------------
REWARD_CATS = ["Groceries", "Dining", "Travel", "Transit & gas", "Online & subscriptions", "Everything else"]
# map budget lines -> reward category
BUDGET_TO_CAT = {"groceries": "Groceries", "dining": "Dining", "travel": "Travel", "transit": "Transit & gas",
                 "subscriptions": "Online & subscriptions", "books": "Online & subscriptions", "personal": "Everything else",
                 "utilities": "Everything else", "phone": "Everything else", "other": "Everything else", "conferences": "Travel"}


def card_optimizer(spend_m: dict, cards: list[dict]) -> dict:
    cat_spend = dict.fromkeys(REWARD_CATS, 0.0)
    for k, v in spend_m.items():
        if k in BUDGET_TO_CAT:
            cat_spend[BUDGET_TO_CAT[k]] += v
    rows = []
    total_best = 0.0
    for cat, s in cat_spend.items():
        rates = [(c["name"], c["rates"].get(cat, 0.0)) for c in cards if c["name"]]
        best = max(rates, key=lambda x: x[1]) if rates else ("–", 0.0)
        yr = s * 12 * best[1] / 100
        total_best += yr
        rows.append({"Category": cat, "Monthly spend": s, "Best card": best[0], "Rate": best[1], "Annual rewards": yr})
    single = {c["name"]: sum(cat_spend[cat] * 12 * c["rates"].get(cat, 0) / 100 for cat in REWARD_CATS) for c in cards if c["name"]}
    return {"table": pd.DataFrame(rows), "total": total_best, "single": single, "spend": cat_spend}


PERKS = [
    ("Software & tools", "GitHub Student Developer Pack", "Free developer tools and cloud credits for verified students.", "https://education.github.com/pack"),
    ("Software & tools", "Microsoft 365 Education", "Free Office apps through most universities: sign in with your .edu.", "https://www.microsoft.com/en-us/education/products/office"),
    ("Software & tools", "JetBrains educational licenses", "Free professional IDEs for students and teachers.", "https://www.jetbrains.com/community/education/"),
    ("Software & tools", "Notion for education", "Free Plus plan with a school email.", "https://www.notion.com/product/notion-for-education"),
    ("Software & tools", "Autodesk education", "Free access to Autodesk software for students.", "https://www.autodesk.com/education/edu-software/overview"),
    ("Shopping", "Amazon Prime Student", "Discounted Prime membership with a trial period for students.", "https://www.amazon.com/amazonprime?planOptimizationId=WLPStudentMonthlyEligiblePlans"),
    ("Shopping", "Apple education pricing", "Education discount on Macs and iPads; seasonal back-to-school offers.", "https://www.apple.com/us-edu/store"),
    ("Shopping", "UNiDAYS", "Verified-student discount marketplace (fashion, tech, food).", "https://www.myunidays.com/US/en-US"),
    ("Shopping", "Student Beans", "Another student-verification discount network.", "https://www.studentbeans.com/us"),
    ("Entertainment", "Spotify Premium Student", "Student plan bundled with other streaming perks.", "https://www.spotify.com/us/student/"),
    ("Travel", "Amtrak student discount", "Discounted fares for students with a valid ID on many routes; check terms.", "https://www.amtrak.com/deals-discounts/value-discounts/students.html"),
    ("Travel", "ISIC card", "International Student Identity Card: discounts abroad.", "https://www.isic.org/"),
    ("Travel", "Conference travel grants", "Professional societies and NSF-funded conferences often offer student travel awards: apply early.", "https://www.google.com/search?q=student+travel+grant+conference"),
    ("Cash back", "Rakuten", "Cash-back shopping portal: click through before buying online.", "https://www.rakuten.com/"),
    ("Cash back", "TopCashback", "Cash-back portal; compare rates with Rakuten per store.", "https://www.topcashback.com/"),
    ("Price tracking", "Google Flights price tracking", "Track routes and get emailed when fares drop.", "https://www.google.com/travel/flights"),
    ("Price tracking", "camelcamelcamel", "Amazon price history and drop alerts.", "https://camelcamelcamel.com/"),
]

DEFAULT_CARDS: list[dict[str, Any]] = [
    {"name": "Flat-rate card", "rates": dict.fromkeys(REWARD_CATS, 2.0)},
    {"name": "Dining & groceries card", "rates": {"Groceries": 3.0, "Dining": 3.0, "Travel": 1.0, "Transit & gas": 1.0, "Online & subscriptions": 1.0, "Everything else": 1.0}},
    {"name": "", "rates": dict.fromkeys(REWARD_CATS, 0.0)},
]
