"""Module 3: planned & unplanned life events, layered on the career path and portfolio Monte Carlo."""
from __future__ import annotations

import numpy as np

from . import budget as B
from . import careers as C
from . import portfolio as PF
from .careers import CURRENT_YEAR


def contribution_schedule(p: dict, path: C.Path, cf: dict, save_rate_after: float, extra_school_years: int = 0,
                          quit_to_masters_year: int | None = None) -> tuple[np.ndarray, int, np.ndarray]:
    """Monthly real contributions to investments from now to retirement, plus income by year."""
    income = path.income.copy()
    school_n = int(sum(ph[1] - ph[0] for ph in path.phases if ph[3] == "school"))
    if extra_school_years:
        stip = p["stipend"] + p.get("summer_income", 0)
        income = np.concatenate([income[:school_n], np.full(extra_school_years, stip), income[school_n:]])[: len(path.income)]
        school_n += extra_school_years
    if quit_to_masters_year is not None and quit_to_masters_year < school_n:
        wf, _ = C.wage_factor(p["target_metro"], p["field"], "industry")
        y = quit_to_masters_year
        income[y:] = C._career_stream(p["masters_salary"] * wf, len(income) - y, "industry", p["salary_growth"] / 100)
        school_n = y
    state = C.metro_row(p["target_metro"])["state"]
    loans = B.loan_projection(p)
    M = len(income) * 12
    contrib = np.zeros(M)
    for y, inc in enumerate(income):
        if y < school_n:
            m = cf["surplus"]
        else:
            m = B.salary_after_tax(inc, state) / 12 * save_rate_after / 100
            if y - school_n < 10:
                m -= loans["payment_10y"] * 0.5  # half of the loan payment comes out of savings, half out of lifestyle
        contrib[y * 12:(y + 1) * 12] = m
    return contrib, school_n, income


def event_shocks(p: dict, ev: dict, n_paths: int, M: int, school_n: int, income: np.ndarray, seed: int = 11) -> tuple[np.ndarray, list[str]]:
    rng = np.random.default_rng(seed)
    S = np.zeros((n_paths, M))
    log = []
    state = C.metro_row(p["target_metro"])["state"]

    def at(year_offset: int, amount: float):
        m = int(np.clip(year_offset * 12, 0, M - 1))
        S[:, m] += amount

    def month_of(cal_year: int) -> int:
        return max(0, cal_year - CURRENT_YEAR)

    if e := ev.get("funding_gap"):
        at(month_of(e["year"]), -p["stipend"] * e["months"] / 12 * 0.85)
        log.append(f"Funding gap in {e['year']}: {e['months']} months without stipend")
    if e := ev.get("internship"):
        at(month_of(e["year"]), e["amount"] * 0.75)
        log.append(f"Summer internship in {e['year']}: +{B.money(e['amount'])} gross")
    if e := ev.get("bonus"):
        at(school_n, e["amount"] * 0.65)
        log.append(f"Signing bonus at graduation: +{B.money(e['amount'])} gross")
    if e := ev.get("layoff"):
        y = school_n + e["years_after"]
        if y < len(income):
            lost = B.salary_after_tax(income[y], state) * e["months"] / 12
            at(y, -lost)
            log.append(f"Layoff {e['years_after']} yrs after graduating: {e['months']} months without pay")
    if e := ev.get("visa_gap"):
        if school_n < len(income):
            at(school_n, -B.salary_after_tax(income[school_n], state) * e["months"] / 12)
            log.append(f"OPT/visa gap after graduation: {e['months']} months before starting work")
    if e := ev.get("child"):
        y0 = month_of(e["year"])
        for k in range(e["years"]):
            if y0 + k < M // 12:
                S[:, (y0 + k) * 12:(y0 + k + 1) * 12] -= e["cost"] / 12
        log.append(f"Child in {e['year']}: {B.money(e['cost'])}/yr childcare for {e['years']} yrs")
    if e := ev.get("medical"):
        at(month_of(e["year"]), -e["cost"])
        log.append(f"Medical emergency in {e['year']}: {B.money(e['cost'])}")
    if e := ev.get("inherit"):
        at(month_of(e["year"]), e["amount"])
        log.append(f"Windfall in {e['year']}: +{B.money(e['amount'])}")
    if e := ev.get("random_layoffs"):
        # each working year: probability of a 4-month gap
        for y in range(school_n, M // 12):
            hit = rng.random(n_paths) < e["prob"] / 100
            S[hit, y * 12] -= B.salary_after_tax(income[y], state) * 4 / 12
        log.append(f"Random job-loss risk: {e['prob']}%/yr chance of a 4-month gap")
    return S, log


def run(p: dict, path: C.Path, cf: dict, mix: dict, ev: dict, start: float, vol_mult: float = 1.0,
        n_paths: int = 1000) -> dict:
    sr = p["save_rate_after"]
    base_c, school_n, inc = contribution_schedule(p, path, cf, sr)
    ev_c, ev_school, ev_inc = contribution_schedule(p, path, cf, sr, extra_school_years=ev.get("extra_year", {}).get("years", 0),
                                                    quit_to_masters_year=(ev["quit"]["year"] - CURRENT_YEAR) if ev.get("quit") else None)
    shocks, log = event_shocks(p, ev, n_paths, len(ev_c), ev_school, ev_inc)
    if ev.get("extra_year"):
        log.insert(0, f"{'PhD' if C.phd_track(p) else 'Degree'} takes {ev['extra_year']['years']} extra year(s)")
    if ev.get("quit"):
        log.insert(0, f"Leave with a master's in {ev['quit']['year']} and go to industry")
    crash = (ev["crash"]["name"], ev["crash"]["offset"]) if ev.get("crash") else None
    if crash:
        log.append(f"Replay {crash[0]} starting {CURRENT_YEAR + crash[1]} (age {p['age'] + crash[1]})")
    base = PF.monte_carlo(mix, start, base_c, n_paths=n_paths, vol_mult=vol_mult)
    scen = PF.monte_carlo(mix, start, ev_c, n_paths=n_paths, vol_mult=vol_mult, crash=crash, shocks=shocks)
    return {"base": base, "scen": scen, "log": log, "school_n": school_n, "ev_school_n": ev_school,
            "income": inc, "ev_income": ev_inc}


def sequence_demo(mix: dict, p: dict, start: float = 50000, monthly: float = 1500, years: int = 15) -> dict:
    """Same contributions; a 2008-style crash in year 1 vs. year 12 (right before you need the money)."""
    M = years * 12
    c = np.full(M, monthly)
    early = PF.monte_carlo(mix, start, c, n_paths=400, seed=3, crash=("2008 Global Financial Crisis", 0))
    late = PF.monte_carlo(mix, start, c, n_paths=400, seed=3, crash=("2008 Global Financial Crisis", years - 3))
    return {"early": early, "late": late}
