"""Downloadable client report: self-contained HTML (print to PDF from the browser)."""
from __future__ import annotations

from datetime import datetime
from html import escape

from .budget import money
from .careers import status_text


def build(p, ctx: dict, disclaimer: str) -> str:
    cf, hs, paths, sel, rec, w, sim, gs, top = (ctx[k] for k in ("cf", "health", "paths", "selected", "rec", "weights", "mc", "goals", "top_metros"))
    t = cf["tax"]
    path_rows = "".join(
        f"<tr{' class=hl' if x['label'] == sel.label else ''}><td>{escape(x['label'])}</td><td class=num>{money(x['start_salary'])}</td>"
        f"<td class=num>{money(x['pv'])}</td><td class=num>{x['years_in_school']}</td></tr>" for x in paths)
    w_rows = "".join(f"<tr><td>{escape(k)}</td><td class=num>{v:.0%}</td></tr>" for k, v in w.items())
    step_rows = "".join(f"<tr><td>{escape(s['step'])}</td><td class=num>{money(s['monthly'])}/mo</td></tr>" for s in cf["steps"] if s["monthly"] > 1)
    goal_rows = "".join(f"<tr><td>{escape(g['label'])}</td><td class=num>{money(g['amount'])}</td><td class=num>{g['year']}</td>"
                        f"<td class=num>{g['pct']:.0%}</td><td>{'On track' if g['on_track'] else 'Behind'}</td></tr>" for g in gs)
    metro_rows = "".join(f"<tr><td>{escape(r['Metro'])}</td><td class=num>{money(r['Salary'])}</td><td class=num>{money(r['Real after-tax'])}</td>"
                         f"<td class=num>{r['Score']:.0f}</td></tr>" for _, r in top.head(5).iterrows())
    return f"""<!DOCTYPE html><html><head><meta charset="utf-8"><link href='https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;600&family=Source+Serif+4:wght@600;700&display=swap' rel='stylesheet'><title>Athena Capital report: {escape(p['name'])}</title>
<style>
body{{font-family:'IBM Plex Sans','Segoe UI',Helvetica,Arial,sans-serif;color:#0B0E14;max-width:860px;margin:32px auto;padding:0 24px;line-height:1.45}}
h1{{font-family:'Source Serif 4',Georgia,serif;color:#0B0E14;margin:0;font-size:28px}} h2{{font-family:'Source Serif 4',Georgia,serif;color:#0B0E14;border-bottom:2px solid #0F4C8A;padding-bottom:4px;margin-top:28px;font-size:19px}}
.sub{{font-family:Helvetica,Arial,sans-serif;color:#5C6573;font-size:13px}} table{{width:100%;border-collapse:collapse;font-family:Helvetica,Arial,sans-serif;font-size:13px}}
th{{text-align:left;border-bottom:1px solid #D9E2EC;font-size:11px;text-transform:uppercase;letter-spacing:.06em;color:#5C6573;padding:5px}}
td{{padding:5px;border-bottom:1px solid #E8EEF5}} td.num{{text-align:right}} tr.hl td{{background:#EEF4FB;font-weight:bold}}
.grid{{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;font-family:Helvetica,Arial,sans-serif}} .k{{border:1px solid #D9E2EC;border-radius:12px;border-top:3px solid #0F4C8A;padding:10px}}
.k b{{display:block;font-family:'Source Serif 4',Georgia,serif;font-size:20px;color:#0B0E14}} .k span{{font-size:11px;text-transform:uppercase;color:#5C6573;letter-spacing:.08em}}
.foot{{font-size:11px;color:#5C6573;margin-top:30px;border-top:1px solid #D9E2EC;padding-top:10px;font-family:Helvetica,Arial,sans-serif}}
</style></head><body>
<h1>Financial plan: {escape(p['name'])}</h1>
<div class=sub>{p['age']} · {escape(status_text(p))} in {escape(p['field'])} · Prepared {datetime.now():%B %d, %Y} by Athena Capital</div>
<h2>1. Profile</h2>
<div class=grid>
<div class=k><span>Health score</span><b>{hs['score']:.0f} ({hs['grade']})</b></div>
<div class=k><span>Net worth</span><b>{money(ctx['nw'])}</b></div>
<div class=k><span>Peer percentile (SCF)</span><b>{ctx['nw_pct']:.0f}th</b></div>
<div class=k><span>Monthly surplus</span><b>{money(cf['surplus'])}</b></div>
<div class=k><span>Risk tolerance</span><b>{rec['tol']:.1f}/10</b></div>
<div class=k><span>Risk capacity</span><b>{rec['cap']:.1f}/10</b></div>
<div class=k><span>Stocks in plan</span><b>{rec['equity']:.0%}</b></div>
<div class=k><span>Stipend vs GRFP (cost-adj.)</span><b>{ctx['stipend_ratio']:.2f}×</b></div>
</div>
<h2>2. Career paths (real 2026 dollars, PV at 4%)</h2>
<table><tr><th>Path</th><th class=num>Starting salary</th><th class=num>PV of earnings</th><th class=num>Years in school</th></tr>{path_rows}</table>
<h2>3. Portfolio</h2>
<table><tr><th>Holding</th><th class=num>Weight</th></tr>{w_rows}</table>
<p>Median projected invested wealth at age 35: <b>{money(sim['p35'])}</b>; at {p['retire_age']}: <b>{money(sim['p65'])}</b> (today's dollars, 1,000 simulations of 1928–2026 history).</p>
<h2>4. Monthly cash flow &amp; taxes</h2>
<p>Take-home {money(cf['take_home'])}/mo · spending {money(cf['spend'])}/mo · surplus <b>{money(cf['surplus'])}/mo</b> ({cf['savings_rate']:.0%} savings rate).
Estimated 2026 tax {money(t['total'])} ({t['effective']:.1%} effective){'; set aside ' + money(t['quarterly']) + ' per quarter for estimated taxes' if t['needs_estimates'] else ''}.</p>
<table><tr><th>Savings waterfall</th><th class=num>Monthly</th></tr>{step_rows}</table>
<h2>5. Goals</h2>
<table><tr><th>Goal</th><th class=num>Target</th><th class=num>By</th><th class=num>Funded</th><th>Status</th></tr>{goal_rows}</table>
<h2>6. Where to live after graduation (top 5 for your profile)</h2>
<table><tr><th>Metro</th><th class=num>Est. salary</th><th class=num>After-tax, cost-adjusted</th><th class=num>Score</th></tr>{metro_rows}</table>
<div class=foot>{escape(disclaimer)}</div>
</body></html>"""
