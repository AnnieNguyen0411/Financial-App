"""Module 4: student taxes, monthly cash flow, savings waterfall, debt and goals."""
from __future__ import annotations

import math

import numpy as np

from . import data as D
from .careers import CURRENT_YEAR, metro_row

EXPENSES = [  # key, label, group (needs / wants / growth)
    ("rent", "Rent", "Needs"), ("utilities", "Utilities & internet", "Needs"), ("groceries", "Groceries", "Needs"),
    ("transit", "Transit & car", "Needs"), ("phone", "Phone", "Needs"), ("health_ins", "Health insurance & care", "Needs"),
    ("books", "Books, software & lab", "Career"), ("conferences", "Conferences (unreimbursed)", "Career"),
    ("dining", "Dining out & coffee", "Wants"), ("subscriptions", "Subscriptions", "Wants"),
    ("travel", "Travel & visits home", "Wants"), ("personal", "Personal & clothing", "Wants"), ("other", "Everything else", "Wants"),
]


def money(x: float, signed: bool = False) -> str:
    if x is None or (isinstance(x, float) and math.isnan(x)):
        return "–"
    s = f"${abs(x):,.0f}"
    if x < 0:
        return "−" + s
    return ("+" + s) if signed else s


# --------------------------------------------------------------------------------------
# Taxes
# --------------------------------------------------------------------------------------
def _brackets_tax(taxable: float, brackets: list) -> float:
    """brackets as [[upper, rate]...] (federal style) -> tax."""
    tax, lower = 0.0, 0.0
    for upper, rate in brackets:
        top = upper if upper is not None else float("inf")
        if taxable > lower:
            tax += (min(taxable, top) - lower) * rate
        lower = top
    return tax


def federal_income_tax(taxable: float) -> float:
    return _brackets_tax(taxable, D.rules()["federal"]["brackets_single"])


def marginal_federal(taxable: float) -> float:
    for upper, rate in D.rules()["federal"]["brackets_single"]:
        if upper is None or taxable <= upper:
            return rate
    return 0.37


def state_income_tax(state: str, agi: float) -> float:
    st = D.rules()["states"]
    if state in st["_none"] or state not in st:
        return 0.0
    s = st[state]
    taxable = max(0.0, agi - s.get("std", 0) - s.get("exemption", 0))
    tax = 0.0
    br = s["brackets"]  # [[threshold, rate], ...] (state style: rate applies above threshold)
    for i, (lo, rate) in enumerate(br):
        hi = br[i + 1][0] if i + 1 < len(br) else float("inf")
        if taxable > lo:
            tax += (min(taxable, hi) - lo) * rate
    return max(0.0, tax - s.get("credit", 0))


def student_taxes(p: dict, pretax_contrib: float = 0.0) -> dict:
    """Annual tax for a graduate student. Handles fellowship vs wage stipends, student FICA exception,
    nonresident aliens (F-1/J-1), side income, and state tax for the university's state."""
    R = D.rules()["federal"]
    state = metro_row(p["univ_metro"])["state"]
    stipend = p["stipend"]
    fel_share = {"fellowship": 1.0, "wages": 0.0, "mixed": p.get("fellowship_share", 50) / 100}[p["stipend_type"]]
    fellowship = stipend * fel_share
    wages = stipend * (1 - fel_share) + p.get("summer_income", 0)
    side = p.get("side_income", 0)
    side_w2 = side if p.get("side_type") == "w2" else 0.0
    side_1099 = side if p.get("side_type") == "1099" else 0.0
    nra = p["residency"] == "intl"

    # payroll taxes
    fica_exempt_school = p.get("student_fica_exempt", True) or nra
    fica = 0.0 if fica_exempt_school else R["fica_employee_rate"] * wages
    fica += 0.0 if nra else R["fica_employee_rate"] * side_w2
    se_tax = 0.0 if nra else R["se_rate"] * 0.9235 * side_1099
    half_se = se_tax / 2

    gross = fellowship + wages + side
    exempt = p.get("treaty_exempt", 0) if nra else 0.0
    agi = max(0.0, gross - half_se - pretax_contrib - exempt)
    std = R["standard_deduction_single"] if (not nra or p.get("india_treaty")) else 0.0
    taxable = max(0.0, agi - std)
    fed = federal_income_tax(taxable)
    st_tax = state_income_tax(state, agi)
    total = fed + st_tax + fica + se_tax
    # income tax that is NOT withheld (fellowship + 1099): pay quarterly
    unwithheld_share = (fellowship + side_1099) / gross if gross else 0
    quarterly = (fed + st_tax) * unwithheld_share / 4 + se_tax / 4
    return {"gross": gross, "fellowship": fellowship, "wages": wages, "side": side, "agi": agi, "taxable": taxable,
            "federal": fed, "state": st_tax, "state_code": state, "fica": fica, "se_tax": se_tax, "total": total,
            "effective": total / gross if gross else 0, "marginal": marginal_federal(taxable), "quarterly": quarterly,
            "needs_estimates": quarterly > 250, "std": std, "nra": nra,
            "ira_compensation": gross}  # SECURE Act: taxable stipends count as compensation


def salary_after_tax(salary: float, state: str) -> float:
    R = D.rules()["federal"]
    fica = R["fica_employee_rate"] * min(salary, R["ss_wage_base"]) + 0.0145 * max(0, salary - R["ss_wage_base"])
    fed = federal_income_tax(max(0, salary - R["standard_deduction_single"]))
    return salary - fed - state_income_tax(state, salary) - fica


# --------------------------------------------------------------------------------------
# Cash flow + waterfall
# --------------------------------------------------------------------------------------
def monthly_expenses(p: dict, trim: dict | None = None) -> dict:
    trim = trim or {}
    return {k: p.get(k, 0) * (1 - trim.get(g, 0) / 100) for k, _, g in EXPENSES}


def cash_flow(p: dict, trim_wants: float = 0.0, extra_cc: float = 0.0) -> dict:
    R = D.rules()
    exp = monthly_expenses(p, {"Wants": trim_wants})
    spend = sum(exp.values())
    tax = student_taxes(p)
    loan_pay = p.get("ug_payment", 0)
    take_home_m = (tax["gross"] - tax["total"]) / 12
    tuition_m = (0 if p.get("tuition_covered", True) else p.get("tuition_cost", 0)) / 12
    borrow_m = p.get("new_borrow", 0) / 12
    surplus = take_home_m + borrow_m - spend - loan_pay - tuition_m

    steps = []
    left = max(0.0, surplus)

    def take(name, want, note, account):
        nonlocal left
        amt = max(0.0, min(left, want))
        left -= amt
        steps.append({"step": name, "monthly": amt, "target": want, "note": note, "account": account})

    needs = sum(v for (_, _, g), v in zip(EXPENSES, exp.values(), strict=True) if g == "Needs")
    if p["cc_debt"] > 0:
        take("Pay off credit card", p["cc_debt"] / 6 + extra_cc, f"{p['cc_rate']:.0f}% APR: clear it within ~6 months", "debt")
    starter = max(0.0, needs - p["cash"])
    take("Starter emergency fund (1 month)", starter / 6, f"{money(needs)} of essential costs", "cash")
    room = max(0.0, min(R["accounts"]["ira_limit"], tax["ira_compensation"]) - p.get("roth_contrib_ytd", 0))
    take("Roth IRA", room / 12, f"2026 limit {money(R['accounts']['ira_limit'])}; your stipend counts as compensation (SECURE Act)", "roth")
    ef_target = p["ef_months"] * needs
    take("Full emergency fund", max(0.0, ef_target - max(p["cash"], needs)) / 12, f"{p['ef_months']} months of essentials = {money(ef_target)}", "cash")
    spare = max(0.0, p["cash"] - ef_target)
    for g in goals(p):
        n = max(1, (g["year"] - CURRENT_YEAR) * 12)
        have = min(spare, g["amount"])
        spare -= have
        take(g["label"], max(0.0, g["amount"] - have) / n, f"{money(g['amount'])} by {g['year']}", "goal")
    if p.get("employer_plan"):
        take("University 403(b)/457(b)", R["accounts"]["deferral_limit_401k_403b_457"] / 12,
             "Pre-tax or Roth; 2026 limit $24,500. Check whether grad employees are eligible", "403b")
    take("Taxable brokerage", left, "Everything else: low-cost index ETFs from your Portfolio Studio mix", "taxable")

    invest_m = sum(s["monthly"] for s in steps if s["account"] in ("roth", "403b", "taxable"))
    save_m = sum(s["monthly"] for s in steps if s["account"] != "debt")
    groups = {}
    for (_, _, g), v in zip(EXPENSES, exp.values(), strict=True):
        groups[g] = groups.get(g, 0) + v
    return {"tax": tax, "exp": exp, "spend": spend, "take_home": take_home_m, "loan_pay": loan_pay, "tuition_m": tuition_m,
            "borrow_m": borrow_m, "surplus": surplus, "steps": steps, "invest_m": invest_m, "save_m": save_m,
            "savings_rate": max(0.0, surplus) / take_home_m if take_home_m > 0 else 0.0, "groups": groups,
            "needs_m": needs, "ef_months_have": p["cash"] / needs if needs else 0}


def goals(p: dict) -> list[dict]:
    out = []
    if p.get("laptop_amt"):
        out.append({"key": "laptop", "label": "New laptop / research gear", "amount": p["laptop_amt"], "year": p["laptop_year"]})
    if p.get("reloc_amt"):
        grad_year = CURRENT_YEAR + remaining_school_years(p)
        out.append({"key": "reloc", "label": "Post-graduation move & deposit", "amount": p["reloc_amt"], "year": grad_year})
    if p.get("home_down_pct"):
        m = metro_row(p["target_metro"])
        price = m.list_price if m.list_price == m.list_price and m.list_price else 400000
        out.append({"key": "home", "label": f"Home down payment ({m['name']})", "amount": price * p["home_down_pct"] / 100,
                    "year": p["home_year"], "price": price})
    return sorted(out, key=lambda g: g["year"])


def remaining_school_years(p: dict) -> int:
    st = p["status"]
    if st == "masters":
        n = p["masters_len"] - p["masters_year"] + 1
        if p.get("plan_after_masters") == "phd":
            n += p["phd_total"]
        return n
    if st == "phd":
        return max(1, p["phd_total"] - p["phd_year"] + 1)
    if st == "postdoc":
        return max(1, p["postdoc_years"])
    if p.get("prospective_program") == "phd":
        return p["phd_total"]
    return p["masters_len"] + (p["phd_total"] if p.get("plan_after_masters") == "phd" else 0)


def goal_status(p: dict, cf: dict) -> list[dict]:
    flows = {s["step"]: s["monthly"] for s in cf["steps"]}
    spare = max(0.0, p["cash"] - p["ef_months"] * cf["needs_m"])
    out = []  # same spare-cash allocation order as the waterfall
    for g in goals(p):
        n = max(1, (g["year"] - CURRENT_YEAR) * 12)
        have = min(spare, g["amount"])
        spare -= have
        need_m = max(0.0, g["amount"] - have) / n
        plan_m = flows.get(g["label"], 0.0)
        projected = have + plan_m * n * 1.03
        pct = min(1.0, projected / g["amount"]) if g["amount"] else 1.0
        gap = max(0.0, need_m - plan_m)
        late = 0 if gap < 1 else (math.inf if plan_m <= 0 else (g["amount"] - have) / plan_m - n)
        out.append({**g, "have": have, "need_m": need_m, "plan_m": plan_m, "projected": projected, "pct": pct,
                    "gap_m": gap, "months_late": late, "on_track": gap < 1})
    return out


def loan_projection(p: dict) -> dict:
    """Unsubsidized loans accrue interest in school; show balance at graduation and a 10-year payoff."""
    yrs = remaining_school_years(p)
    R = D.rules()["loans"]
    bal_ug = p["ug_loan"] * (1 + p["ug_rate"] / 100) ** yrs if p.get("ug_payment", 0) == 0 else p["ug_loan"]
    grad = p["grad_loan"] * (1 + p["grad_rate"] / 100) ** yrs
    for k in range(yrs):  # new borrowing each year at the 2026-27 grad rate
        grad += p.get("new_borrow", 0) * (1 - R["origination_fee"]) * (1 + R["grad_unsub_rate_2026_27"]) ** (yrs - k - 0.5)
    total = bal_ug + grad
    r = 0.07 / 12
    pay10 = total * r / (1 - (1 + r) ** -120) if total > 0 else 0.0
    return {"years_in_school": yrs, "balance_at_grad": total, "payment_10y": pay10,
            "interest_accrued": total - p["ug_loan"] - p["grad_loan"] - p.get("new_borrow", 0) * yrs,
            "cap_warning": p.get("new_borrow", 0) * yrs + p["grad_loan"] > R["aggregate_limit_grad"]}


def debt_payoff(balance: float, apr: float, payment: float) -> tuple[int, float]:
    if balance <= 0:
        return 0, 0.0
    r = apr / 100 / 12
    if payment <= balance * r:
        return 999, float("inf")
    m, interest = 0, 0.0
    while balance > 0 and m < 999:
        i = balance * r
        interest += i
        balance += i - payment
        m += 1
    return m, interest


def health_score(p: dict, cf: dict, nw_pct: float, stipend_ratio: float) -> dict:
    parts = {
        "Savings rate": np.clip(cf["savings_rate"] / 0.15, 0, 1),
        "Emergency fund": np.clip(cf["ef_months_have"] / max(p["ef_months"], 1), 0, 1),
        "High-interest debt": 0.0 if p["cc_debt"] > 1000 else (0.6 if p["cc_debt"] > 0 else 1.0),
        "Retirement started": 1.0 if p["roth_ira"] + p["pretax_ret"] > 0 else 0.3,
        "Net worth vs peers": nw_pct / 100,
    }
    if stipend_ratio:  # unfunded students aren't penalized for having no stipend
        parts["Stipend purchasing power"] = np.clip(stipend_ratio / 1.2, 0, 1)
    score = float(np.mean(list(parts.values())) * 100)
    grade = "A" if score >= 85 else "B" if score >= 70 else "C" if score >= 55 else "D"
    return {"score": score, "grade": grade, "parts": parts}
